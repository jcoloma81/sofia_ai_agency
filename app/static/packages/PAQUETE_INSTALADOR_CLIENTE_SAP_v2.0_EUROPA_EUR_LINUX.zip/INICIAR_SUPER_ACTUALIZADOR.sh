#!/usr/bin/env bash
cd "$(dirname "$0")"
PORT=8765
echo "================================================================="
echo "🚀 Iniciando Súper Actualizador Pro (Edición Enterprise Local)..."
echo "🌐 Abriendo aplicación en ventana de escritorio independiente..."
echo "================================================================="
# Si no existe venv local, crearlo automáticamente para Linux
if [ ! -f "venv/bin/uvicorn" ]; then
    echo "📦 Preparando entorno de ejecución para Linux por primera vez..."
    python3 -m venv venv
    ./venv/bin/pip install -r requirements.txt
fi

(
  sleep 2
  URL="http://127.0.0.1:$PORT"
  if command -v google-chrome >/dev/null 2>&1; then
      google-chrome --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v chromium >/dev/null 2>&1; then
      chromium --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v chromium-browser >/dev/null 2>&1; then
      chromium-browser --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v brave-browser >/dev/null 2>&1; then
      brave-browser --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v microsoft-edge >/dev/null 2>&1; then
      microsoft-edge --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  else
      xdg-open "$URL" >/dev/null 2>&1 || true
  fi
) &
./venv/bin/uvicorn app:app --host 127.0.0.1 --port $PORT
