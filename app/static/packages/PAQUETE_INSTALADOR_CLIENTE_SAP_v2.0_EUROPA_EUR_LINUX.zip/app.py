"""
Servidor Principal Local ("Web Moderna adentro de la PC")
Súper Actualizador Pro - Edición Enterprise Local
"""

import json
import shutil
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

from generar_excels_prueba import crear_excels_de_prueba
from licencias import (
    activar_licencia_en_disco,
    consumir_prueba_si_es_base,
    obtener_estado_licencia_actual,
    obtener_hardware_id,
    solicitar_demo_servidor,
)
from motor_inteligente import (
    BACKUPS_DIR,
    EXPORTADOS_DIR,
    comparar_listas_proveedores,
    cotizar_radar_mercadolibre,
    exportar_catalogo_personalizado_p1,
    guardar_config,
    guardar_emparejamiento_memoria,
    inspeccionar_hojas_excel,
    obtener_config,
    obtener_estadisticas_memoria,
    procesar_actualizacion_enterprise,
)

BASE_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = BASE_DIR / "templates"
UPLOADS_DIR = BASE_DIR / "uploads_temp"
EJEMPLOS_DIR = BASE_DIR / "ejemplos_prueba"

TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
UPLOADS_DIR.mkdir(parents=True, exist_ok=True)

# Asegurar que existan las planillas de ejemplo al iniciar
crear_excels_de_prueba()

app = FastAPI(
    title="Súper Actualizador Pro - Edición Enterprise Local",
    version="2.0.0",
)


class ActivarLicenciaReq(BaseModel):
    clave: str


class SolicitarDemoReq(BaseModel):
    comercio: Optional[str] = "Comercio"
    whatsapp: Optional[str] = None


class SimularNivelReq(BaseModel):
    tipo: str
    cliente: Optional[str] = "Comercio Demo"


class ConfigGeminiReq(BaseModel):
    api_key: str


class ItemP1Seleccionado(BaseModel):
    codigo: str
    seleccionado: bool = True
    cantidad: int = 0
    articulo_catalogo: Optional[str] = ""
    costo_anterior: Optional[float] = 0.0
    costo_nuevo_limpio: Optional[float] = 0.0
    variacion_porc: Optional[float] = 0.0
    venta_nueva: Optional[float] = 0.0


class ExportarPersonalizadoP1Req(BaseModel):
    nombre_backup: str
    nombre_proveedor: str
    items: List[ItemP1Seleccionado]
    modo_margen: str = "RESPETAR_EXCEL"
    margen_fijo_porc: float = 45.0
    hoja_catalogo: Optional[str] = None


class RadarMLReq(BaseModel):
    consulta: str
    comision_ml_porc: float = 25.0
    pais_id: str = "argentina"


class VincularManualReq(BaseModel):
    proveedor: str
    clave_prov: str
    texto_prov: str
    codigo_cat: str
    nombre_cat: str


def obtener_perfil_regional() -> dict:
    """Carga la configuración de moneda, impuestos y pasarelas de la región empaquetada."""
    ruta_perfil = BASE_DIR / "perfil_regional.json"
    if ruta_perfil.exists():
        try:
            return json.loads(ruta_perfil.read_text(encoding="utf-8"))
        except Exception:
            pass
    ruta_arg = BASE_DIR / "perfiles_regionales" / "argentina.json"
    if ruta_arg.exists():
        try:
            return json.loads(ruta_arg.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {
        "region_id": "argentina",
        "nombre_region": "Argentina",
        "moneda_simbolo": "$",
        "moneda_codigo": "ARS",
        "idioma": "es",
        "precio_pro_texto": "$ 35.000 ARS",
        "metodo_pago_titulo": "Mercado Pago / Transferencia",
        "metodo_pago_subtitulo": "Transferí por Mercado Pago o cualquier banco:",
        "metodo_pago_alias": "pagoslemon.cash",
        "metodo_pago_url": "",
        "iva_default": 21.0,
        "iva_opciones": [
            {"label": "+21% (IVA General)", "valor": 21.0},
            {"label": "+10.5% (IVA Reducido)", "valor": 10.5},
            {"label": "0% (IVA ya incluido / Exento)", "valor": 0.0}
        ],
        "soporte_whatsapp": "+54 9 343 453-6447",
        "soporte_mensaje": "Hola Javier! Quiero consultar para activar la versión definitiva FULL PRO para mi negocio."
    }


@app.get("/", response_class=HTMLResponse)
def servir_interfaz_principal():
    ruta_html = TEMPLATES_DIR / "index.html"
    if not ruta_html.exists():
        return HTMLResponse("<h1>Cargando interfaz...</h1>")
    contenido = ruta_html.read_text(encoding="utf-8")
    perfil = obtener_perfil_regional()
    tag_script = f"<script>window.PERFIL_REGIONAL = {json.dumps(perfil, ensure_ascii=False)};</script>\n</head>"
    contenido = contenido.replace("</head>", tag_script, 1)
    return HTMLResponse(contenido)


@app.get("/api/config/regional")
def api_config_regional():
    """Devuelve la configuración regional activa del cliente."""
    return obtener_perfil_regional()


@app.get("/video-promocional")
def servir_video_promocional():
    """Sirve el video promocional oficial de 59 segundos generado con voz en off."""
    ruta_video = BASE_DIR / "video_promocional_sap_pro.mp4"
    if ruta_video.exists():
        return FileResponse(ruta_video, media_type="video/mp4")
    from fastapi.responses import RedirectResponse
    return RedirectResponse("https://sofia-ai-agency.onrender.com/assets/video_promocional_sap_pro.mp4")


# =====================================================================
# ENDPOINTS DE LICENCIAS Y CANDADO HARDWARE ID
# =====================================================================

@app.get("/api/licencia/estado")
def api_estado_licencia():
    estado = obtener_estado_licencia_actual()
    return {
        "estado": estado,
    }


@app.post("/api/licencia/activar")
def api_activar_licencia(req: ActivarLicenciaReq):
    res = activar_licencia_en_disco(req.clave)
    if not res.get("activada") and not res.get("valida", True):
        raise HTTPException(status_code=400, detail=res.get("motivo", "Clave de licencia inválida."))
    return {"ok": True, "estado": res}


@app.post("/api/licencia/solicitar-demo")
def api_solicitar_demo(req: SolicitarDemoReq):
    res = solicitar_demo_servidor(req.comercio, req.whatsapp)
    if not res.get("activada"):
        raise HTTPException(status_code=400, detail=res.get("motivo", "No se pudo activar la demo."))
    return {"ok": True, "estado": res}


# =====================================================================
# ENDPOINTS DE CONFIGURACIÓN IA (GEMINI) Y MEMORIA SQLITE
# =====================================================================

@app.get("/api/config/estado")
def api_obtener_config():
    key = obtener_config("gemini_api_key", "")
    key_mascara = (key[:6] + "..." + key[-4:]) if len(key) > 10 else ("Configurada" if key else "")
    return {
        "tiene_api_key": bool(key),
        "api_key_mascara": key_mascara,
        "memoria": obtener_estadisticas_memoria(),
    }


@app.post("/api/config/gemini")
def api_guardar_gemini_key(req: ConfigGeminiReq):
    guardar_config("gemini_api_key", req.api_key.strip())
    return {"ok": True, "tiene_api_key": bool(req.api_key.strip())}


@app.post("/api/memoria/vincular-manual")
def api_vincular_manual(req: VincularManualReq):
    guardar_emparejamiento_memoria(
        req.proveedor,
        req.clave_prov,
        req.texto_prov,
        req.codigo_cat,
        req.nombre_cat,
        origen="MANUAL_1_CLIC",
    )
    return {"ok": True, "memoria": obtener_estadisticas_memoria()}


@app.post("/api/inspeccionar-hojas")
async def api_inspeccionar_hojas(archivo: UploadFile = File(...)):
    """Inspecciona si el Excel tiene múltiples solapas para dar selector al comerciante."""
    ruta_temp = UPLOADS_DIR / f"temp_inspect_{archivo.filename}"
    with open(ruta_temp, "wb") as f:
        shutil.copyfileobj(archivo.file, f)
    hojas = inspeccionar_hojas_excel(ruta_temp)
    try:
        ruta_temp.unlink(missing_ok=True)
    except Exception:
        pass
    return {"nombre": archivo.filename, "hojas": hojas}


# =====================================================================
# PESTAÑA 1: ACTUALIZADOR DE PRECIOS ENTERPRISE
# =====================================================================

@app.post("/api/pestana1/actualizar")
async def api_pestana1_actualizar(
    usar_ejemplo: bool = Form(False),
    nombre_proveedor: str = Form("BULONERA Y HERRAMIENTAS DEL SUR"),
    descuento_1: float = Form(10.0),
    descuento_2: float = Form(5.0),
    reglas_descuento: Optional[str] = Form(""),
    iva_porc: float = Form(21.0),
    flete_porc: float = Form(0.0),
    modo_margen: str = Form("RESPETAR_EXCEL"),
    margen_fijo_porc: float = Form(45.0),
    modo_redondeo: str = Form("REDONDEO_10"),
    umbral_alerta_porc: float = Form(35.0),
    hoja_catalogo: Optional[str] = Form(None),
    hoja_proveedor: Optional[str] = Form(None),
    archivo_catalogo: Optional[UploadFile] = File(None),
    archivo_proveedor: Optional[UploadFile] = File(None),
):
    estado_lic = obtener_estado_licencia_actual()
    if not estado_lic.get("activada") or not estado_lic.get("permisos", {}).get("pestana_1_actualizador"):
        raise HTTPException(
            status_code=403,
            detail=estado_lic.get("motivo") or "Programa sin licencia activa. Ingresá tu clave de activación en el botón superior 'Licencia'.",
        )

    if usar_ejemplo or not archivo_catalogo or not archivo_proveedor:
        crear_excels_de_prueba()
        ruta_cat = EJEMPLOS_DIR / "1_mi_catalogo_ferreteria_actual.xlsx"
        ruta_prov = EJEMPLOS_DIR / "2_lista_nueva_proveedor_whatsapp.xlsx"
    else:
        ruta_cat = UPLOADS_DIR / f"cat_{archivo_catalogo.filename}"
        ruta_prov = UPLOADS_DIR / f"prov_{archivo_proveedor.filename}"
        with open(ruta_cat, "wb") as f:
            shutil.copyfileobj(archivo_catalogo.file, f)
        with open(ruta_prov, "wb") as f:
            shutil.copyfileobj(archivo_proveedor.file, f)

    # Sanitización de nombres de hojas
    hoja_cat_str = str(hoja_catalogo).strip() if isinstance(hoja_catalogo, str) and hoja_catalogo.strip() and hoja_catalogo.strip() != "null" else None
    hoja_prov_str = str(hoja_proveedor).strip() if isinstance(hoja_proveedor, str) and hoja_proveedor.strip() and hoja_proveedor.strip() != "null" else None

    try:
        resultado = procesar_actualizacion_enterprise(
            ruta_catalogo_cliente=ruta_cat,
            ruta_lista_proveedor=ruta_prov,
            nombre_proveedor=nombre_proveedor,
            descuento_1=descuento_1,
            descuento_2=descuento_2,
            iva_porc=iva_porc,
            flete_porc=flete_porc,
            modo_margen=modo_margen,
            margen_fijo_porc=margen_fijo_porc,
            modo_redondeo=modo_redondeo,
            umbral_alerta_porc=umbral_alerta_porc,
            hoja_catalogo=hoja_cat_str,
            hoja_proveedor=hoja_prov_str,
            reglas_descuento_marcas=reglas_descuento,
        )
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as ex:
        raise HTTPException(
            status_code=400,
            detail=f"No se pudo procesar el archivo subido. Verificá que sea un Excel, CSV, PDF o imagen válida ({ex}).",
        )
    resultado["memoria"] = obtener_estadisticas_memoria()
    return resultado


@app.post("/api/pestana1/exportar-personalizado")
def api_pestana1_exportar_personalizado(req: ExportarPersonalizadoP1Req):
    """
    Exporta el catálogo actualizado aplicando cambios ÚNICAMENTE a los artículos tildados,
    y genera el pedido para este proveedor si hay cantidades asignadas.
    """
    estado_lic = obtener_estado_licencia_actual()
    if not estado_lic.get("activada") or not estado_lic.get("permisos", {}).get("pestana_1_actualizador"):
        raise HTTPException(
            status_code=403,
            detail=estado_lic.get("motivo") or "Programa sin licencia activa. Activá tu licencia para exportar el catálogo.",
        )

    try:
        items_dict = [it.model_dump() for it in req.items]
        resultado = exportar_catalogo_personalizado_p1(
            nombre_backup=req.nombre_backup,
            nombre_proveedor=req.nombre_proveedor,
            items_seleccionados=items_dict,
            modo_margen=req.modo_margen,
            margen_fijo_porc=req.margen_fijo_porc,
            hoja_catalogo=req.hoja_catalogo,
        )
        return resultado
    except Exception as ex:
        raise HTTPException(status_code=400, detail=str(ex))


# =====================================================================
# PESTAÑA 2: COMPARADOR DE PROVEEDORES ("DÓNDE COMPRAR MÁS BARATO HOY")
# =====================================================================

@app.post("/api/pestana2/comparar")
async def api_pestana2_comparar(
    usar_ejemplo: bool = Form(False),
    nombre_p1: str = Form("Mayorista del Norte"),
    desc_p1: float = Form(0.0),
    desc2_p1: float = Form(0.0),
    iva_p1: float = Form(21.0),
    nombre_p2: str = Form("Distribuidora Oeste"),
    desc_p2: float = Form(0.0),
    desc2_p2: float = Form(0.0),
    iva_p2: float = Form(21.0),
    nombre_p3: str = Form("Importadora Central"),
    desc_p3: float = Form(0.0),
    desc2_p3: float = Form(0.0),
    iva_p3: float = Form(21.0),
    nombre_p4: str = Form("Proveedor 4"),
    desc_p4: float = Form(0.0),
    desc2_p4: float = Form(0.0),
    iva_p4: float = Form(21.0),
    nombre_p5: str = Form("Proveedor 5"),
    desc_p5: float = Form(0.0),
    desc2_p5: float = Form(0.0),
    iva_p5: float = Form(21.0),
    hoja_p1: Optional[str] = Form(None),
    hoja_p2: Optional[str] = Form(None),
    hoja_p3: Optional[str] = Form(None),
    hoja_p4: Optional[str] = Form(None),
    hoja_p5: Optional[str] = Form(None),
    archivo_p1: Optional[UploadFile] = File(None),
    archivo_p2: Optional[UploadFile] = File(None),
    archivo_p3: Optional[UploadFile] = File(None),
    archivo_p4: Optional[UploadFile] = File(None),
    archivo_p5: Optional[UploadFile] = File(None),
):
    permiso = consumir_prueba_si_es_base("comparador")
    if not permiso.get("permitido"):
        raise HTTPException(status_code=403, detail=permiso.get("motivo"))

    listas_config = []
    if usar_ejemplo:
        crear_excels_de_prueba()
        listas_config = [
            {
                "nombre": nombre_p1 or "Mayorista del Norte",
                "ruta_excel": EJEMPLOS_DIR / "3_mayorista_del_norte.xlsx",
                "descuento_porc": desc_p1,
                "descuento_2_porc": desc2_p1,
                "iva_porc": iva_p1,
                "hoja": hoja_p1,
            },
            {
                "nombre": nombre_p2 or "Distribuidora Oeste",
                "ruta_excel": EJEMPLOS_DIR / "4_distribuidora_oeste.xlsx",
                "descuento_porc": desc_p2,
                "descuento_2_porc": desc2_p2,
                "iva_porc": iva_p2,
                "hoja": hoja_p2,
            },
            {
                "nombre": nombre_p3 or "Importadora Central",
                "ruta_excel": EJEMPLOS_DIR / "5_importadora_central.xlsx",
                "descuento_porc": desc_p3,
                "descuento_2_porc": desc2_p3,
                "iva_porc": iva_p3,
                "hoja": hoja_p3,
            },
        ]
    else:
        for idx, (arch, nom, d1, d2, iv, hj) in enumerate(
            [
                (archivo_p1, nombre_p1, desc_p1, desc2_p1, iva_p1, hoja_p1),
                (archivo_p2, nombre_p2, desc_p2, desc2_p2, iva_p2, hoja_p2),
                (archivo_p3, nombre_p3, desc_p3, desc2_p3, iva_p3, hoja_p3),
                (archivo_p4, nombre_p4, desc_p4, desc2_p4, iva_p4, hoja_p4),
                (archivo_p5, nombre_p5, desc_p5, desc2_p5, iva_p5, hoja_p5),
            ],
            start=1,
        ):
            if arch and arch.filename:
                r_temp = UPLOADS_DIR / f"comp_{idx}_{arch.filename}"
                with open(r_temp, "wb") as f:
                    shutil.copyfileobj(arch.file, f)
                listas_config.append(
                    {
                        "nombre": (nom or f"Proveedor {idx}").strip(),
                        "ruta_excel": r_temp,
                        "descuento_porc": d1,
                        "descuento_2_porc": d2,
                        "iva_porc": iv,
                        "hoja": hj,
                    }
                )

    if len(listas_config) < 2:
        raise HTTPException(
            status_code=400,
            detail="Por favor, seleccioná al menos 2 archivos Excel de proveedores para comparar precios.",
        )

    try:
        res = comparar_listas_proveedores(listas_config)
    except ValueError as ve:
        raise HTTPException(status_code=400, detail=str(ve))
    except Exception as ex:
        raise HTTPException(
            status_code=400,
            detail=f"Error al leer una de las listas de proveedores. Verificá que el archivo no esté dañado o protegido ({ex}).",
        )
    res["estado_licencia"] = obtener_estado_licencia_actual()
    return res


class ItemPedidoSeleccionado(BaseModel):
    sku: str
    articulo: str
    cantidad: int
    costo_limpio_unitario: float
    subtotal_estimado: float
    ahorro_vs_mas_caro: float


class GenerarPedidoPersonalizadoReq(BaseModel):
    proveedor: str
    items: List[ItemPedidoSeleccionado]


@app.post("/api/pestana2/generar-pedido-personalizado")
def api_generar_pedido_personalizado(req: GenerarPedidoPersonalizadoReq):
    import re
    from datetime import datetime
    import pandas as pd

    if not req.items:
        raise HTTPException(status_code=400, detail="No hay ningún artículo seleccionado para este proveedor.")

    slug = re.sub(r"[^a-zA-Z0-9]+", "_", req.proveedor).strip("_")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    nom_archivo = f"PEDIDO_PERSONALIZADO_{slug}_{timestamp}.xlsx"
    ruta_archivo = EXPORTADOS_DIR / nom_archivo

    filas = []
    total_pesos = 0.0
    total_ahorro = 0.0
    for it in req.items:
        sub = round(it.costo_limpio_unitario * it.cantidad, 2)
        total_pesos += sub
        total_ahorro += it.ahorro_vs_mas_caro
        filas.append({
            "SKU": it.sku,
            "Articulo": it.articulo,
            "Cantidad_a_Pedir": it.cantidad,
            "Costo_Limpio_Unitario": it.costo_limpio_unitario,
            "Subtotal_Estimado": sub,
            "Ahorro_vs_Mas_Caro": it.ahorro_vs_mas_caro,
        })

    df = pd.DataFrame(filas)
    df.to_excel(ruta_archivo, index=False)

    return {
        "ok": True,
        "archivo": nom_archivo,
        "url": f"/api/descargar/exportados/{nom_archivo}",
        "proveedor": req.proveedor,
        "total_items": len(filas),
        "subtotal_total": round(total_pesos, 2),
        "ahorro_total": round(total_ahorro, 2),
    }


# =====================================================================
# PESTAÑA 3: RADAR MERCADOLIBRE + EL JUEZ INTELIGENTE
# =====================================================================

@app.post("/api/pestana3/radar-ml")
def api_pestana3_radar_ml(req: RadarMLReq):
    permiso = consumir_prueba_si_es_base("radar_ml")
    if not permiso.get("permitido"):
        raise HTTPException(status_code=403, detail=permiso.get("motivo"))

    res = cotizar_radar_mercadolibre(req.consulta, req.comision_ml_porc, pais_id=req.pais_id)
    res["estado_licencia"] = obtener_estado_licencia_actual()
    return res


# =====================================================================
# DESCARGA DE ARCHIVOS EXCEL (ACTUALIZADOS, PEDIDOS, BACKUPS Y EJEMPLOS)
# =====================================================================

@app.get("/api/descargar/{carpeta}/{nombre_archivo}")
def api_descargar_archivo(carpeta: str, nombre_archivo: str):
    mapa_carpetas = {
        "exportados": EXPORTADOS_DIR,
        "backups": BACKUPS_DIR,
        "ejemplos": EJEMPLOS_DIR,
    }
    dir_base = mapa_carpetas.get(carpeta.lower())
    if not dir_base:
        raise HTTPException(status_code=400, detail="Carpeta inválida")

    ruta = (dir_base / nombre_archivo).resolve()
    if not ruta.exists() or dir_base.resolve() not in ruta.parents:
        raise HTTPException(status_code=404, detail="Archivo no encontrado")

    return FileResponse(
        path=ruta,
        filename=ruta.name,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
