"""
Sistema de Candado Comercial Asimétrico (RSA-2048) y Validación de Licencias
para Súper Actualizador Pro v2.0 (Edición Enterprise).

Seguridad Criptográfica:
- La validación se realiza mediante Llave Pública RSA-2048 embebida.
- Es matemáticamente imposible generar claves válidas (Keygens) sin la Llave Privada.
- Soporta activación automática de Demo por internet (vía Sofía AI Agency)
  y activación manual offline para licencias permanentes FULL PRO.
"""

import base64
import hashlib
import json
import os
import platform
import re
import urllib.error
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

BASE_DIR = Path(__file__).resolve().parent
LICENSE_FILE = BASE_DIR / "licencia_activa.json"
USAGE_FILE = BASE_DIR / "estado_uso.json"

# Llave Pública RSA-2048 Oficial de Sofía AI Agency (Solo valida firmas, no puede firmar)
_RSA_PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt0MlZ1nNzOZxRdLBEiFU
7d8HftP+1igoMUdysDNi1et9a65c7CFHhYfw23tWpGWy7hvgI+B1NdGhHzx9acJu
hZtDId+OnVT23kn1b2PmR03BYYLxKzZG++pk7h7MAcZPWqzPQAMKobaMDZ49Xsck
XRTJboaf22OrF9E5rkPvPhcn30PS5HyAS2Br54tlTFY2cufpn+FcAVsSL3m46aiW
ijyXxdncgeAvzn33GjATlsHQSsi4QRPhzysmwAOMTGzxyWkxpgz9O/I9+qjkAESo
BTaFK9Oy4zdmVZTCimC1z1Qbo9WhTCDeqWMOoYe/IHW7Px3HIoo/D8sFW/WIhG82
mwIDAQAB
-----END PUBLIC KEY-----"""


def obtener_hardware_id() -> str:
    """
    Obtiene una huella única y estable de la PC del comerciante (Windows / Linux / Mac)
    y la formatea como: SAP-XXXX-XXXX-XXXX
    """
    componentes = []
    componentes.append(platform.node() or "PC")
    componentes.append(platform.machine() or "x86_64")

    machine_id_leido = ""
    for ruta in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
        try:
            if os.path.exists(ruta):
                with open(ruta, "r", encoding="utf-8") as f:
                    machine_id_leido = f.read().strip()
                if machine_id_leido:
                    break
        except Exception:
            pass

    if machine_id_leido:
        componentes.append(machine_id_leido)
    else:
        componentes.append(str(uuid.getnode()))

    raw = "|".join(componentes).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest().upper()
    return f"SAP-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"


def verificar_clave_licencia(clave: str, hardware_id_actual: Optional[str] = None) -> Dict[str, Any]:
    """
    Verifica si una clave de licencia es auténtica usando verificación RSA-2048,
    corresponde a esta PC y no venció.
    """
    if hardware_id_actual is None:
        hardware_id_actual = obtener_hardware_id()

    hw_actual = re.sub(r"[^A-Za-z0-9_-]", "", str(hardware_id_actual or "")).upper()
    clave_limpia = re.sub(r"[^A-Za-z0-9_.-]", "", str(clave or "")).strip()

    if not clave_limpia or "." not in clave_limpia:
        return {"valida": False, "motivo": "Formato de clave inválido."}

    try:
        prefijo_y_payload, firma_b64 = clave_limpia.rsplit(".", 1)
        partes_prefijo = prefijo_y_payload.split("-", 2)
        if len(partes_prefijo) != 3 or partes_prefijo[0] != "LIC":
            return {"valida": False, "motivo": "Estructura de licencia no reconocida."}

        payload_b64 = partes_prefijo[2]

        # Validar firma RSA con la llave pública
        pad_sig = "=" * (-len(firma_b64) % 4)
        firma_bytes = base64.urlsafe_b64decode((firma_b64 + pad_sig).encode("ascii"))

        pub_key = serialization.load_pem_public_key(_RSA_PUBLIC_KEY_PEM)
        pub_key.verify(
            firma_bytes,
            payload_b64.encode("ascii"),
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
            hashes.SHA256(),
        )

        # Si verify no lanzó excepción, la firma es 100% auténtica y no fue alterada
        pad_payload = "=" * (-len(payload_b64) % 4)
        payload_bytes = base64.urlsafe_b64decode((payload_b64 + pad_payload).encode("ascii"))
        datos = json.loads(payload_bytes.decode("utf-8"))

        hw_licencia = datos.get("hw", "").upper()
        # Permitir comodín MASTER-ANY sólo si fue emitido por la firma de Sofía
        if hw_licencia != hw_actual and hw_licencia != "SAP-MASTER-ANY":
            return {
                "valida": False,
                "motivo": f"Esta clave pertenece a otra PC ({hw_licencia}). Tu ID actual es {hw_actual}.",
            }

        fecha_venc = datos.get("v", "PERMANENTE")
        dias_restantes = None
        if fecha_venc != "PERMANENTE":
            dt_venc = datetime.strptime(fecha_venc, "%Y-%m-%d").date()
            hoy = datetime.now().date()
            dias_restantes = (dt_venc - hoy).days
            if dias_restantes < 0:
                return {
                    "valida": False,
                    "vencida": True,
                    "motivo": f"La licencia DEMO venció el {fecha_venc}. Contactá a soporte para activar tu licencia definitiva.",
                }

        tipo = datos.get("t", "BASE")
        return {
            "valida": True,
            "tipo": tipo,
            "cliente": datos.get("c", "Comercio"),
            "hardware_id": hw_actual,
            "fecha_emision": datos.get("e"),
            "fecha_vencimiento": fecha_venc,
            "dias_restantes": dias_restantes,
        }
    except Exception as e:
        return {"valida": False, "motivo": f"Firma o clave inválida: {str(e)}"}


def solicitar_demo_servidor(comercio: Optional[str] = "Comercio", whatsapp: Optional[str] = None) -> Dict[str, Any]:
    """
    Solicita la activación automática de 7 días al servidor de Sofía AI Agency en la nube.
    Utiliza requests + certifi o urllib con contexto SSL resiliente para Windows Embeddable.
    """
    hw_id = obtener_hardware_id()
    default_url = "https://sofia-ai-agency.onrender.com/api/licencias/activar-demo"
    api_url = os.environ.get("SAP_LICENSE_SERVER_URL", default_url)

    payload = {
        "hardware_id": hw_id,
        "comercio": (comercio or "Comercio").strip(),
        "whatsapp": (whatsapp or "").strip(),
    }
    headers = {
        "Content-Type": "application/json",
        "User-Agent": "SuperActualizadorPro/2.0",
    }

    # 1. Intentar primero con requests (usa certifi en Windows portable)
    try:
        import requests
        try:
            import certifi
            ca_file = certifi.where()
        except Exception:
            ca_file = True

        try:
            resp = requests.post(api_url, json=payload, headers=headers, timeout=15, verify=ca_file)
        except requests.exceptions.SSLError:
            # Fallback seguro: la clave devuelta se valida con RSA-2048 localmente
            resp = requests.post(api_url, json=payload, headers=headers, timeout=15, verify=False)

        if resp.status_code == 200:
            res_json = resp.json()
            clave = res_json.get("clave")
            if not clave:
                return {"valida": False, "motivo": "El servidor de activación no devolvió una clave."}
            return activar_licencia_en_disco(clave)
        else:
            try:
                err_body = resp.json()
                motivo = err_body.get("detail", f"Error {resp.status_code}")
            except Exception:
                motivo = f"Error del servidor de activación ({resp.status_code})"
            return {"valida": False, "motivo": motivo}

    except Exception as e_req:
        pass

    # 2. Fallback a urllib con contexto SSL que soporte Windows portable
    try:
        import ssl
        try:
            import certifi
            ctx = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            ctx = ssl._create_unverified_context()

        req_data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(api_url, data=req_data, headers=headers, method="POST")

        with urllib.request.urlopen(req, context=ctx, timeout=15) as response:
            res_json = json.loads(response.read().decode("utf-8"))
            clave = res_json.get("clave")
            if not clave:
                return {"valida": False, "motivo": "El servidor de activación no devolvió una clave."}
            return activar_licencia_en_disco(clave)
    except urllib.error.HTTPError as e:
        try:
            err_body = json.loads(e.read().decode("utf-8"))
            motivo = err_body.get("detail", str(e))
        except Exception:
            motivo = f"Error del servidor de activación ({e.code})"
        return {"valida": False, "motivo": motivo}
    except Exception as e:
        return {
            "valida": False,
            "motivo": (
                f"No se pudo conectar con el servidor de activación ({str(e)}). "
                "Verificá tu conexión a internet o contactá a un asesor por WhatsApp para activación manual."
            ),
        }


def _cargar_uso() -> Dict[str, Any]:
    if USAGE_FILE.exists():
        try:
            with open(USAGE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"usos_comparador": 0, "usos_radar_ml": 0}


def _guardar_uso(uso: Dict[str, Any]) -> None:
    with open(USAGE_FILE, "w", encoding="utf-8") as f:
        json.dump(uso, f, indent=2, ensure_ascii=False)


def obtener_estado_licencia_actual() -> Dict[str, Any]:
    """
    Lee la licencia guardada en disco y devuelve los permisos de cada pestaña
    y cuántas pruebas gratis le quedan en caso de tener LICENCIA BASE.
    """
    hw_id = obtener_hardware_id()
    uso = _cargar_uso()
    max_pruebas_base = 3

    if not LICENSE_FILE.exists():
        return {
            "activada": False,
            "hardware_id": hw_id,
            "tipo": "SIN_ACTIVAR",
            "cliente": "Comercio no activado",
            "motivo": "El sistema requiere activación obligatoria para comenzar tu prueba gratuita de 7 días.",
            "mensaje": "¡Bienvenido! Activá tu prueba gratuita de 7 días en 1 clic o ingresá tu clave de activación.",
            "permisos": {
                "pestana_1_actualizador": False,
                "pestana_2_comparador": False,
                "pestana_3_radar_ml": False,
                "pestana_4_corporativo": False,
            },
            "pruebas_restantes": {
                "comparador": 0,
                "radar_ml": 0,
            },
            "requiere_activacion": True,
        }

    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            guardado = json.load(f)
        clave = guardado.get("clave", "")
    except Exception:
        clave = ""

    verif = verificar_clave_licencia(clave, hw_id)
    if not verif.get("valida"):
        vencida = bool(verif.get("vencida", False))
        return {
            "activada": False,
            "hardware_id": hw_id,
            "tipo": "VENCIDA" if vencida else "INVALIDA",
            "cliente": "Comercio",
            "motivo": verif.get("motivo", "Licencia no válida o vencida"),
            "mensaje": (
                "Tu período de prueba gratuita de 7 días ha finalizado. Para continuar utilizando el sistema sin límites, contactá a soporte por WhatsApp para activar tu Licencia Definitiva FULL PRO."
                if vencida
                else verif.get("motivo", "Licencia no válida")
            ),
            "permisos": {
                "pestana_1_actualizador": False,
                "pestana_2_comparador": False,
                "pestana_3_radar_ml": False,
                "pestana_4_corporativo": False,
            },
            "pruebas_restantes": {
                "comparador": 0,
                "radar_ml": 0,
            },
            "requiere_upgrade": True,
            "vencida": vencida,
        }

    tipo = verif["tipo"]
    restantes_comp = max(0, max_pruebas_base - int(uso.get("usos_comparador", 0)))
    restantes_ml = max(0, max_pruebas_base - int(uso.get("usos_radar_ml", 0)))

    if tipo in ("FULL_PRO", "DEMO_7_DIAS"):
        permisos = {
            "pestana_1_actualizador": True,
            "pestana_2_comparador": True,
            "pestana_3_radar_ml": True,
            "pestana_4_corporativo": True,
        }
    else:  # BASE
        permisos = {
            "pestana_1_actualizador": True,
            "pestana_2_comparador": restantes_comp > 0,
            "pestana_3_radar_ml": restantes_ml > 0,
            "pestana_4_corporativo": True,
        }

    return {
        "activada": True,
        "hardware_id": hw_id,
        "tipo": tipo,
        "cliente": verif.get("cliente", "Comercio"),
        "fecha_emision": verif.get("fecha_emision"),
        "fecha_vencimiento": verif.get("fecha_vencimiento"),
        "dias_restantes": verif.get("dias_restantes"),
        "clave": clave,
        "permisos": permisos,
        "pruebas_restantes": {
            "comparador": "ILIMITADO" if tipo in ("FULL_PRO", "DEMO_7_DIAS") else restantes_comp,
            "radar_ml": "ILIMITADO" if tipo in ("FULL_PRO", "DEMO_7_DIAS") else restantes_ml,
        },
    }


def activar_licencia_en_disco(clave: str) -> Dict[str, Any]:
    """Valida y guarda una clave de licencia en la PC del comerciante."""
    clave_limpia = re.sub(r"[^A-Za-z0-9_.-]", "", str(clave or "")).strip()
    verif = verificar_clave_licencia(clave_limpia)
    if not verif.get("valida"):
        return verif

    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(
            {
                "clave": clave_limpia,
                "activada_el": datetime.now().isoformat(),
            },
            f,
            indent=2,
            ensure_ascii=False,
        )
    return obtener_estado_licencia_actual()


def consumir_prueba_si_es_base(modulo: str) -> Dict[str, Any]:
    """
    Si la licencia activa es BASE, descuenta 1 uso de prueba del módulo ('comparador' o 'radar_ml').
    """
    estado = obtener_estado_licencia_actual()
    if not estado.get("activada"):
        return {
            "permitido": False,
            "motivo": estado.get("motivo") or "Debés activar tu licencia para usar este módulo.",
        }

    tipo = estado["tipo"]
    if tipo in ("FULL_PRO", "DEMO_7_DIAS"):
        return {"permitido": True, "restantes": "ILIMITADO"}

    uso = _cargar_uso()
    campo = "usos_comparador" if modulo == "comparador" else "usos_radar_ml"
    usados = int(uso.get(campo, 0))
    if usados >= 3:
        return {
            "permitido": False,
            "bloqueo_upgrade": True,
            "motivo": (
                "¡Completaste tus 3 pruebas gratuitas de este módulo en tu LICENCIA BASE! "
                "Solicitá tu actualización a LICENCIA FULL PRO para destrabar el Comparador de Proveedores "
                "y el Radar MercadoLibre sin límites para siempre."
            ),
        }

    uso[campo] = usados + 1
    _guardar_uso(uso)
    return {"permitido": True, "restantes": max(0, 3 - uso[campo])}
