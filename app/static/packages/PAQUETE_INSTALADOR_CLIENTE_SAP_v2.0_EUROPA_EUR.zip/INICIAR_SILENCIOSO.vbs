' ==============================================================================
' SUPER ACTUALIZADOR PRO - INICIO SILENCIOSO CON PROTECCION DE EXTRACCION
' ==============================================================================
Option Explicit

Dim FSO, scriptDir, WshShell, msg, titulo

Set FSO = CreateObject("Scripting.FileSystemObject")
scriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)

' 1. Verificacion de Extraccion: si se ejecuta dentro del ZIP, avisar amablemente
If Not FSO.FileExists(FSO.BuildPath(scriptDir, "motor_inteligente.py")) Or Not FSO.FileExists(FSO.BuildPath(scriptDir, "INICIAR_WINDOWS.bat")) Then
    titulo = "S" & ChrW(250) & "per Actualizador PRO " & ChrW(8212) & " Debes Extraer el Archivo"
    msg = "ATENCI" & ChrW(211) & "N:" & vbCrLf & vbCrLf & _
          "Para poder utilizar el S" & ChrW(250) & "per Actualizador PRO, primero debes EXTRAER la carpeta descargada:" & vbCrLf & vbCrLf & _
          "1. Haz clic derecho sobre el archivo ZIP que descargaste." & vbCrLf & _
          "2. Elige 'Extraer todo...' y presiona el bot" & ChrW(243) & "n 'Extraer'." & vbCrLf & _
          "3. Entra a la nueva carpeta extra" & ChrW(237) & "da y haz doble clic en INICIAR_SILENCIOSO." & vbCrLf & vbCrLf & _
          ChrW(161) & "Con eso el sistema se abrir" & ChrW(225) & " autom" & ChrW(225) & "ticamente en tu navegador!"
    MsgBox msg, vbExclamation, titulo
    WScript.Quit 1
End If

' 2. Ejecutar de forma 100% silenciosa en segundo plano (sin consolas negras)
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = scriptDir
WshShell.Run "INICIAR_WINDOWS.bat", 0, False

Set WshShell = Nothing
Set FSO = Nothing
