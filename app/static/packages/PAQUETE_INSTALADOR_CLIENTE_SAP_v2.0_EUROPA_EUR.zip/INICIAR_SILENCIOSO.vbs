' ==============================================================================
' SUPER ACTUALIZADOR PRO - INICIO SILENCIOSO CON PROTECCIÓN DE EXTRACCIÓN
' ==============================================================================
Option Explicit

Dim FSO, scriptDir, WshShell

Set FSO = CreateObject("Scripting.FileSystemObject")
scriptDir = FSO.GetParentFolderName(WScript.ScriptFullName)

' 1. Verificación de Extracción: si se ejecuta dentro del ZIP, avisar amablemente
If Not FSO.FileExists(FSO.BuildPath(scriptDir, "motor_inteligente.py")) Or Not FSO.FileExists(FSO.BuildPath(scriptDir, "INICIAR_WINDOWS.bat")) Then
    MsgBox "ATENCIÓN:" & vbCrLf & vbCrLf & _
           "Para poder utilizar el Súper Actualizador PRO, primero debes EXTRAER la carpeta descargada:" & vbCrLf & vbCrLf & _
           "1. Haz clic derecho sobre el archivo ZIP que descargaste." & vbCrLf & _
           "2. Elige 'Extraer todo...' y presiona el botón 'Extraer'." & vbCrLf & _
           "3. Entra a la nueva carpeta extraída y haz doble clic en INICIAR_SILENCIOSO." & vbCrLf & vbCrLf & _
           "¡Con eso el sistema se abrirá automáticamente en tu navegador!", _
           vbExclamation, "Súper Actualizador PRO — Debes Extraer el Archivo"
    WScript.Quit 1
End If

' 2. Ejecutar de forma 100% silenciosa en segundo plano (sin consolas negras)
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = scriptDir
WshShell.Run "INICIAR_WINDOWS.bat", 0, False

Set WshShell = Nothing
Set FSO = Nothing
