@echo off
title Super Actualizador Pro - Edicion Enterprise Local v2.0
cd /d "%~dp0"
set PORT=8765

:: 0. Verificacion de extraccion: Asegurar que NO se ejecute dentro del ZIP
if not exist "%~dp0motor_inteligente.py" (
    echo.
    echo =======================================================================
    echo   [AVISO CRITICO: DEBES EXTRAER EL ARCHIVO ZIP PRIMERO]
    echo.
    echo   Estas intentando abrir el programa adentro de la carpeta comprimida.
    echo   Para que funcione, primero debes EXTRAERLA:
    echo.
    echo   1. Hace CLIC DERECHO sobre el archivo descargado.
    echo   2. Hace clic en "Extraer todo..." y luego en "Extraer".
    echo   3. Entra a la NUEVA carpeta extraida que se creo en tu pantalla.
    echo   4. Hace doble clic en INICIAR_WINDOWS.bat.
    echo =======================================================================
    echo.
    mshta "javascript:alert('ATENCION:\n\nPara iniciar el programa, primero debes EXTRAER la carpeta.\n\n1. Haz clic derecho sobre el archivo descargado.\n2. Elige \'Extraer todo...\' y presiona Extraer.\n3. Entra a la nueva carpeta y haz doble clic en INICIAR_WINDOWS.bat.');close();"
    pause
    exit /b 1
)

echo =======================================================================
echo   SUPER ACTUALIZADOR PRO - EDICION ENTERPRISE LOCAL v2.0
echo   100%% Local en tu PC - Tus datos nunca salen de tu comercio
echo =======================================================================
echo.

:: 1. Liberar el puerto si quedo tomado por una sesion previa
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :%PORT% ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>nul
)

:: 2. Iniciar la aplicacion en ventana de escritorio independiente (Modo App)
echo Iniciando servidor en http://127.0.0.1:%PORT% ...
echo (La aplicacion se abrira como ventana independiente en unos segundos)
echo.

set "BROWSER_EXE="
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER_EXE if exist "%LocalAppData%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%LocalAppData%\Microsoft\Edge\Application\msedge.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER_EXE if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if not defined BROWSER_EXE if exist "%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe" set "BROWSER_EXE=%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe"

if defined BROWSER_EXE (
    start /b powershell -WindowStyle Hidden -Command "$u='http://127.0.0.1:%PORT%'; for ($i=0; $i -lt 60; $i++) { try { $r=[System.Net.WebRequest]::Create($u).GetResponse(); $r.Close(); break } catch { Start-Sleep -Milliseconds 400 } }; Start-Process -FilePath '%BROWSER_EXE%' -ArgumentList ('--app=' + $u)"
) else (
    start /b powershell -WindowStyle Hidden -Command "$u='http://127.0.0.1:%PORT%'; for ($i=0; $i -lt 60; $i++) { try { $r=[System.Net.WebRequest]::Create($u).GetResponse(); $r.Close(); break } catch { Start-Sleep -Milliseconds 400 } }; Start-Process $u"
)

:: 3. Ejecutar directamente con el motor portable pre-instalado (0.5 segundos)
if exist "%~dp0motor_windows\python.exe" (
    "%~dp0motor_windows\python.exe" -m uvicorn app:app --host 127.0.0.1 --port %PORT%
) else if exist "%~dp0venv\Scripts\python.exe" (
    "%~dp0venv\Scripts\python.exe" -m uvicorn app:app --host 127.0.0.1 --port %PORT%
) else (
    python -m uvicorn app:app --host 127.0.0.1 --port %PORT%
)

echo.
echo =======================================================================
echo   El servidor se ha detenido.
echo =======================================================================
pause
