"""
Motor Contable, Cruce Inteligente en 3 Capas (Diccionario Argentino + Gemini API + Memoria SQLite),
Comparador de Proveedores y Radar MercadoLibre con Juez Inteligente.
"""

import json
import math
import re
import shutil
import sqlite3
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import pandas as pd
import requests
from bs4 import BeautifulSoup

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "memoria_proveedores.db"
BACKUPS_DIR = BASE_DIR / "Backups"
EXPORTADOS_DIR = BASE_DIR / "Exportados"

BACKUPS_DIR.mkdir(parents=True, exist_ok=True)
EXPORTADOS_DIR.mkdir(parents=True, exist_ok=True)


# =====================================================================
# 1. BASE DE DATOS LOCAL SQLITE (CAPA 3: MEMORIA ETERNA + CONFIG)
# =====================================================================

def inicializar_db() -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS memoria_emparejamientos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            proveedor TEXT NOT NULL,
            clave_proveedor TEXT NOT NULL,
            texto_proveedor TEXT,
            codigo_catalogo TEXT NOT NULL,
            nombre_catalogo TEXT,
            origen TEXT DEFAULT 'AUTOMATICO',
            actualizado_el TEXT,
            UNIQUE(proveedor, clave_proveedor)
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS configuracion (
            clave TEXT PRIMARY KEY,
            valor TEXT
        )
        """
    )
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS historial_actualizaciones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT,
            proveedor TEXT,
            archivo_original TEXT,
            archivo_backup TEXT,
            archivo_salida TEXT,
            total_articulos INTEGER,
            actualizados INTEGER,
            alertas_rojas INTEGER
        )
        """
    )
    conn.commit()
    conn.close()


inicializar_db()


def guardar_config(clave: str, valor: str) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO configuracion (clave, valor) VALUES (?, ?)",
        (clave, valor),
    )
    conn.commit()
    conn.close()


def obtener_config(clave: str, por_defecto: str = "") -> str:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT valor FROM configuracion WHERE clave = ?", (clave,))
    fila = cur.fetchone()
    conn.close()
    return fila[0] if fila and fila[0] is not None else por_defecto


def guardar_emparejamiento_memoria(
    proveedor: str,
    clave_prov: str,
    texto_prov: str,
    codigo_cat: str,
    nombre_cat: str,
    origen: str = "MEMORIA",
) -> None:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT OR REPLACE INTO memoria_emparejamientos
        (proveedor, clave_proveedor, texto_proveedor, codigo_catalogo, nombre_catalogo, origen, actualizado_el)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
        (
            proveedor.strip().upper(),
            clave_prov.strip().upper(),
            texto_prov,
            str(codigo_cat).strip(),
            nombre_cat,
            origen,
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ),
    )
    conn.commit()
    conn.close()


def consultar_memoria_proveedor(proveedor: str) -> Dict[str, Dict[str, str]]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        SELECT clave_proveedor, codigo_catalogo, nombre_catalogo, origen
        FROM memoria_emparejamientos
        WHERE proveedor = ?
        """,
        (proveedor.strip().upper(),),
    )
    filas = cur.fetchall()
    conn.close()
    return {
        f[0]: {"codigo_catalogo": f[1], "nombre_catalogo": f[2], "origen": f[3]}
        for f in filas
    }


def obtener_estadisticas_memoria() -> Dict[str, Any]:
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*), COUNT(DISTINCT proveedor) FROM memoria_emparejamientos")
    total, provs = cur.fetchone()
    cur.execute(
        """
        SELECT proveedor, texto_proveedor, codigo_catalogo, nombre_catalogo, origen, actualizado_el
        FROM memoria_emparejamientos
        ORDER BY id DESC LIMIT 25
        """
    )
    recientes = [
        {
            "proveedor": r[0],
            "texto_proveedor": r[1],
            "codigo_catalogo": r[2],
            "nombre_catalogo": r[3],
            "origen": r[4],
            "fecha": r[5],
        }
        for r in cur.fetchall()
    ]
    conn.close()
    return {
        "total_emparejamientos_aprendidos": total or 0,
        "proveedores_registrados": provs or 0,
        "recientes": recientes,
    }


# =====================================================================
# 2. CAPA 1: DICCIONARIO ARGENTINO DE FERRETERÍA / REPUESTOS / COMERCIO
# =====================================================================

DICCIONARIO_ABREVIATURAS_ARG = {
    r"\bc/\b": " con ",
    r"\bc/arand\.?\b": " con arandela ",
    r"\bs/\b": " sin ",
    r"\bp/\b": " para ",
    r"\bp/acero\b": " para acero ",
    r"\btorn\.?\b": " tornillo ",
    r"\bautoperf\.?\b": " autoperforante ",
    r"\bhex\.?\b": " hexagonal ",
    r"\barand\.?\b": " arandela ",
    r"\bpulg\.?\b": " pulgadas ",
    r"\bang\.?\b": " angular ",
    r"\bperc\.?\b": " percutor ",
    r"\bcto\.?\b": " corte ",
    r"\binox\.?\b": " inoxidable ",
    r"\bmet\.?\b": " metrica ",
    r"\bacet\.?\b": " acetica ",
    r"\btransp\.?\b": " transparente ",
    r"\bcart\.?\b": " cartucho ",
    r"\bterm\.?\b": " termica ",
    r"\bbip\.?\b": " bipolar ",
    r"\bamp\.?\b": " amperes ",
    r"\bag\.?\b": " agua ",
    r"\balg\.?\b": " algodon ",
    r"\bantidesliz\.?\b": " antideslizante ",
    r"\bpta\.?\b": " punta ",
    r"\bcja\.?\b": " caja ",
    r"\bjgo\.?\b": " juego ",
    r"\bpzas\.?\b": " piezas ",
    r"\bpza\.?\b": " pieza ",
    r"\bpl\.?\b": " plano ",
    r"\bph\.?\b": " phillips ",
    r"\bimant\.?\b": " imantados ",
    r"\bdestorn\.?\b": " destornilladores ",
    r"\bhidrolav\.?\b": " hidrolavadora ",
    r"\b4\s*1/2\b": " 115mm ",
}

STOPWORDS_COMERCIO = {
    "de", "del", "la", "el", "los", "las", "con", "sin", "para", "por", "en", "y", "o", "un", "una"
}


def normalizar_texto_argentino(texto: str) -> str:
    if not texto:
        return ""
    s = str(texto).lower().strip()
    # Quitar tildes
    s = "".join(
        c for c in unicodedata.normalize("NFD", s) if unicodedata.category(c) != "Mn"
    )
    # Reemplazar barras pegadas tipo c/arandela o p/acero
    s = re.sub(r"\bc/([a-z0-9])", r"con \1", s)
    s = re.sub(r"\bp/([a-z0-9])", r"para \1", s)
    s = re.sub(r"\bs/([a-z0-9])", r"sin \1", s)

    for patron, reemplazo in DICCIONARIO_ABREVIATURAS_ARG.items():
        s = re.sub(patron, reemplazo, s)

    # Normalizar unidades pegadas: "115mm" -> "115 mm", "5m" -> "5 metros", "25a" -> "25 amperes"
    s = re.sub(r"(\d+)\s*mm\b", r"\1 milimetros", s)
    s = re.sub(r"(\d+)\s*m\b", r"\1 metros", s)
    s = re.sub(r"(\d+)\s*ml\b", r"\1 mililitros", s)
    s = re.sub(r"(\d+)\s*kg\b", r"\1 kilos", s)
    s = re.sub(r"(\d+)\s*a\b", r"\1 amperes", s)
    s = re.sub(r"(\d+)\s*x\s*(\d+)", r"\1 x \2", s)
    # Normalizar decimales en medidas ej 2.50 -> 2.5
    s = re.sub(r"(\d+\.\d*?)0+\b", r"\1", s)
    s = re.sub(r"\.(\s|$)", r"\1", s)

    # Limpiar caracteres especiales dejando letras, números y puntos decimales
    s = re.sub(r"[^a-z0-9\.\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def extraer_tokens_y_numeros(texto_norm: str) -> Tuple[set, set]:
    palabras = [
        p for p in texto_norm.split() if len(p) > 1 and p not in STOPWORDS_COMERCIO
    ]
    tokens = set(palabras)
    numeros = set(re.findall(r"\d+(?:\.\d+)?", texto_norm))
    return tokens, numeros


def calcular_similitud_capa1(texto_prov: str, texto_cat: str) -> float:
    norm_p = normalizar_texto_argentino(texto_prov)
    norm_c = normalizar_texto_argentino(texto_cat)
    if not norm_p or not norm_c:
        return 0.0
    if norm_p == norm_c:
        return 1.0

    tok_p, num_p = extraer_tokens_y_numeros(norm_p)
    tok_c, num_c = extraer_tokens_y_numeros(norm_c)
    if not tok_p or not tok_c:
        return 0.0

    # Coincidencia de palabras (con soporte de prefijos de al menos 5 letras)
    coincidencias_palabras = 0.0
    for tp in tok_p:
        if tp in tok_c:
            coincidencias_palabras += 1.0
        elif len(tp) >= 5 and any(tc.startswith(tp[:5]) or tp.startswith(tc[:5]) for tc in tok_c if len(tc) >= 5):
            coincidencias_palabras += 0.85

    union_len = len(tok_p | tok_c)
    score_palabras = coincidencias_palabras / max(1, min(len(tok_p), len(tok_c)))
    jaccard = coincidencias_palabras / max(1, union_len)

    # Coincidencia de medidas/números clave (vital en ferretería y repuestos)
    if num_p and num_c:
        num_comunes = len(num_p & num_c)
        score_numeros = num_comunes / max(len(num_p), len(num_c))
    else:
        score_numeros = 0.7

    score_final = (score_palabras * 0.50) + (jaccard * 0.25) + (score_numeros * 0.25)
    return min(1.0, round(score_final, 4))


# =====================================================================
# 3. CAPA 2: IA GOOGLE GEMINI (BATCH MATCHING ULTRA ECONÓMICO)
# =====================================================================

def emparejar_con_gemini_batch(
    items_dificiles: List[Dict[str, str]],
    catalogo_candidatos: List[Dict[str, str]],
    api_key: str,
) -> Dict[str, str]:
    """
    Envía en un solo lote compacto los artículos que la Capa 1 no pudo cruzar con alta certeza
    a la API de Google Gemini (gemini-2.5-flash / gemini-2.0-flash) y devuelve {clave_prov: codigo_catalogo}.
    """
    if not api_key or not items_dificiles or not catalogo_candidatos:
        return {}

    prompt = (
        "Sos un experto ferretero y analista de catálogos comerciales de Argentina.\n"
        "Emparejá cada ítem de la LISTA PROVEEDOR con su equivalente exacto del CATÁLOGO COMERCIO.\n"
        "Si un ítem no tiene equivalente en el catálogo, asignale null.\n"
        "Respondé ÚNICAMENTE un objeto JSON válido con formato: {\"ID_PROV\": \"CODIGO_CATALOGO\"}\n\n"
        f"CATÁLOGO COMERCIO:\n{json.dumps(catalogo_candidatos, ensure_ascii=False)}\n\n"
        f"LISTA PROVEEDOR A EMPAREJAR:\n{json.dumps(items_dificiles, ensure_ascii=False)}"
    )

    for modelo in ["gemini-2.5-flash", "gemini-2.0-flash"]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={api_key.strip()}"
        try:
            resp = requests.post(
                url,
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "generationConfig": {"temperature": 0.0, "responseMimeType": "application/json"},
                },
                timeout=15,
            )
            if resp.status_code == 200:
                data = resp.json()
                texto = (
                    data.get("candidates", [{}])[0]
                    .get("content", {})
                    .get("parts", [{}])[0]
                    .get("text", "{}")
                )
                limpio = re.sub(r"^```json\s*|\s*```$", "", texto.strip())
                resultado = json.loads(limpio)
                if isinstance(resultado, dict):
                    return {str(k): str(v) for k, v in resultado.items() if v}
        except Exception:
            continue
    return {}


# =====================================================================
# 4. DETECTOR AUTOMÁTICO DE COLUMNAS DE EXCEL Y MOTOR CONTABLE REAL
# =====================================================================

def detectar_columnas_excel(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """Detecta automáticamente cuál es la columna de Código, Descripción, Costo, Margen, Precio Venta y Descuento."""
    cols = list(df.columns)
    mapa = {
        "codigo": None,
        "descripcion": None,
        "precio_costo": None,
        "margen": None,
        "precio_venta": None,
        "descuento": None,
    }

    for c in cols:
        cl = str(c).lower().strip()
        if mapa["codigo"] is None and (
            any(k in cl for k in ["cod", "sku", "art_cod", "ean", "barcode", "barras", "c.barra", "c_barra"])
            or cl == "id" or cl.startswith("id_") or cl.endswith("_id") or "id " in cl or " id" in cl or "ident" in cl
        ):
            mapa["codigo"] = c
        elif mapa["descripcion"] is None and any(k in cl for k in ["art", "desc", "prod", "det", "nombre", "item", "titulo"]):
            mapa["descripcion"] = c
        elif mapa["margen"] is None and (any(k in cl for k in ["margen", "utilidad", "ganancia", "markup"]) or cl in ["porc", "%", "porc_margen", "margen_porc"]):
            mapa["margen"] = c
        elif mapa["descuento"] is None and any(k in cl for k in ["dto", "bonif", "descuento"]) and "descrip" not in cl:
            mapa["descuento"] = c
        elif mapa["precio_venta"] is None and any(k in cl for k in ["venta", "publico", "mostrador", "final", "pvp"]):
            mapa["precio_venta"] = c
        elif mapa["precio_costo"] is None and any(k in cl for k in ["costo", "precio", "lista", "unitario", "neto", "importe", "valor"]):
            mapa["precio_costo"] = c

    # Fallbacks si las columnas tienen nombres genéricos
    if mapa["codigo"] is None and len(cols) >= 1:
        mapa["codigo"] = cols[0]
    if mapa["descripcion"] is None and len(cols) >= 2:
        mapa["descripcion"] = cols[1]
    if mapa["precio_costo"] is None and len(cols) >= 3:
        if cols[2] != mapa["precio_venta"] and cols[2] != mapa["codigo"] and cols[2] != mapa["descripcion"]:
            mapa["precio_costo"] = cols[2]
        elif len(cols) >= 4 and cols[3] != mapa["precio_venta"]:
            mapa["precio_costo"] = cols[3]

    return mapa


def parsear_reglas_descuento(texto_reglas: Optional[str]) -> Dict[str, float]:
    """
    Parsea reglas opcionales de descuento por marca/palabra clave.
    Ej: 'BOSCH: 15, STANLEY: 25%' -> {'BOSCH': 15.0, 'STANLEY': 25.0}
    """
    if not texto_reglas or not isinstance(texto_reglas, str):
        return {}
    reglas = {}
    lineas = re.split(r"[,;\n]+", texto_reglas)
    for l in lineas:
        l = l.strip()
        if not l or ":" not in l:
            continue
        partes = l.split(":", 1)
        clave = partes[0].strip().upper()
        val_str = partes[1].replace("%", "").strip()
        try:
            val = float(val_str)
            if clave and val > 0:
                reglas[clave] = val
        except ValueError:
            continue
    return reglas


def limpiar_texto_celda(val: Any) -> str:
    """Evita que celdas vacías (NaN/None) se conviertan en 'nan' y normaliza códigos enteros/EAN/científicos."""
    if val is None or pd.isna(val):
        return ""
    if isinstance(val, float) and val.is_integer():
        return str(int(val))
    s = str(val).strip()
    if s.lower() in ("nan", "none", "null", "<na>"):
        return ""
    # Si Excel guardó un código entero como float ej. '10450.0', quitar el '.0'
    if re.match(r"^\d+\.0$", s):
        s = s[:-2]
    # Si viene en notación científica de Excel ej. '7.791234567890e+12'
    elif re.match(r"^\d+(\.\d+)?[eE][+-]?\d+$", s):
        try:
            fl = float(s)
            if fl.is_integer():
                s = str(int(fl))
        except Exception:
            pass
    return s


def limpiar_numero_moneda(val: Any) -> float:
    if val is None or pd.isna(val):
        return 0.0
    if isinstance(val, (int, float)):
        if math.isnan(val) or math.isinf(val):
            return 0.0
        return float(val)
    s = str(val).strip()
    s = re.sub(r"[^\d,\.-]", "", s)
    if not s or s in ("-", ".", ","):
        return 0.0
    # Si tiene punto de miles y coma decimal (ej. 1.452,38)
    if "," in s and "." in s:
        if s.rfind(",") > s.rfind("."):
            s = s.replace(".", "").replace(",", ".")
        else:
            s = s.replace(",", "")
    elif "," in s:
        # Si hay una sola coma y 1 o 2 dígitos detrás, es coma decimal; si hay 3 dígitos (ej 12,500), puede ser miles
        partes = s.split(",")
        if len(partes) == 2 and len(partes[1]) <= 2:
            s = s.replace(",", ".")
        else:
            s = s.replace(",", "")
    try:
        res = float(s)
        return 0.0 if (math.isnan(res) or math.isinf(res)) else res
    except Exception:
        return 0.0


def calcular_costo_y_venta_contable(
    precio_lista_proveedor: float,
    descuentos_cascada: List[float],
    iva_porc: float,
    flete_porc: float,
    margen_porc: float,
    modo_redondeo: str = "2_DECIMALES",
) -> Dict[str, float]:
    """
    Motor Contable Real:
    1) Aplica bonificaciones/descuentos en cascada (ej. -10% y luego -5% sobre el subtotal).
    2) Suma el IVA configurable (+21%, +10.5% o 0%).
    3) Suma el porcentaje de flete/logística.
    4) Aplica el margen de ganancia.
    5) Formatea según selector: '2_DECIMALES' (ERP/Tango) o 'REDONDEO_10', 'REDONDEO_50', 'REDONDEO_100'.
    """
    costo = float(precio_lista_proveedor)
    for d in descuentos_cascada:
        if d > 0:
            costo = costo * (1.0 - (float(d) / 100.0))
        elif d < 0:
            # Por si ingresan "-10" con signo negativo
            costo = costo * (1.0 - (abs(float(d)) / 100.0))

    costo_con_iva = costo * (1.0 + (float(iva_porc) / 100.0))
    costo_real_limpio = costo_con_iva * (1.0 + (float(flete_porc) / 100.0))

    precio_venta_bruto = costo_real_limpio * (1.0 + (float(margen_porc) / 100.0))

    if modo_redondeo == "REDONDEO_10":
        precio_venta_final = float(math.ceil(precio_venta_bruto / 10.0) * 10)
    elif modo_redondeo == "REDONDEO_50":
        precio_venta_final = float(math.ceil(precio_venta_bruto / 50.0) * 50)
    elif modo_redondeo == "REDONDEO_100":
        precio_venta_final = float(math.ceil(precio_venta_bruto / 100.0) * 100)
    elif modo_redondeo == "REDONDEO_500":
        precio_venta_final = float(math.ceil(precio_venta_bruto / 500.0) * 500)
    elif modo_redondeo == "REDONDEO_1000":
        precio_venta_final = float(math.ceil(precio_venta_bruto / 1000.0) * 1000)
    elif modo_redondeo == "REDONDEO_050":
        precio_venta_final = round(math.ceil(precio_venta_bruto * 2.0) / 2.0, 2)
    elif modo_redondeo == "REDONDEO_ENTERO" or modo_redondeo == "SIN_DECIMALES":
        precio_venta_final = float(round(precio_venta_bruto))
    elif modo_redondeo == "TERMINACION_99":
        entero = math.floor(precio_venta_bruto)
        precio_venta_final = round(entero + 0.99, 2) if precio_venta_bruto >= 1.0 else round(precio_venta_bruto, 2)
    elif modo_redondeo == "TERMINACION_90":
        entero = math.floor(precio_venta_bruto)
        precio_venta_final = round(entero + 0.90, 2) if precio_venta_bruto >= 1.0 else round(precio_venta_bruto, 2)
    elif modo_redondeo == "TERMINACION_990":
        if precio_venta_bruto >= 1000.0:
            miles = math.floor(precio_venta_bruto / 1000.0)
            precio_venta_final = float(miles * 1000 + 990)
        else:
            precio_venta_final = float(math.ceil(precio_venta_bruto / 10.0) * 10)
    else:
        precio_venta_final = round(precio_venta_bruto, 2)

    return {
        "costo_real_limpio": round(costo_real_limpio, 2),
        "precio_venta_final": precio_venta_final,
    }


def _extraer_tabla_con_gemini_vision(ruta_archivo: Path, mime_type: str, api_key: str) -> List[Dict[str, Any]]:
    """
    Usa la Visión Artificial de Google Gemini (gemini-2.5-flash / gemini-2.0-flash)
    para extraer códigos, descripciones y precios unitarios desde un PDF o Foto de factura/remito.
    """
    import base64

    if not api_key or not ruta_archivo.exists():
        return []

    b64_data = base64.b64encode(ruta_archivo.read_bytes()).decode("ascii")
    prompt = (
        "Extraé todos los artículos, productos o renglones de esta lista de precios, factura o remito.\n"
        "Respondé ÚNICAMENTE un arreglo JSON válido con este formato exacto:\n"
        "[{\"Codigo\": \"SKU o código si figura, o vacío\", \"Articulo\": \"Descripción completa del producto\", \"Precio_Lista\": 1234.50, \"Cant_Sugerida\": 1}]"
    )

    for modelo in ["gemini-2.5-flash", "gemini-2.0-flash"]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={api_key.strip()}"
        try:
            resp = requests.post(
                url,
                json={
                    "contents": [
                        {
                            "parts": [
                                {"text": prompt},
                                {"inlineData": {"mimeType": mime_type, "data": b64_data}},
                            ]
                        }
                    ],
                    "generationConfig": {"temperature": 0.0, "responseMimeType": "application/json"},
                },
                timeout=25,
            )
            if resp.status_code == 200:
                data = resp.json()
                texto = (
                    data.get("candidates", [{}])[0]
                    .get("content", {})
                    .get("parts", [{}])[0]
                    .get("text", "[]")
                )
                limpio = re.sub(r"^```json\s*|\s*```$", "", texto.strip())
                filas = json.loads(limpio)
                if isinstance(filas, list) and filas:
                    return filas
        except Exception:
            continue
    return []


def _extraer_tabla_pdf_local(ruta_pdf: Path) -> List[Dict[str, Any]]:
    """
    Extractor local en Python (pypdf) para listas de precios en PDF con texto seleccionable.
    Busca renglones que contengan descripción y precio al final de la línea.
    """
    from pypdf import PdfReader

    filas: List[Dict[str, Any]] = []
    try:
        reader = PdfReader(str(ruta_pdf))
        patron_linea = re.compile(
            r"^\s*([A-Z0-9\-_]{3,15})?\s*(.+?)\s+\$?\s*(\d{1,3}(?:[\.,]\d{3})*(?:[\.,]\d{1,2})?|\d+(?:[\.,]\d{1,2})?)\s*$"
        )
        for page in reader.pages:
            texto = page.extract_text() or ""
            for linea in texto.splitlines():
                linea_str = linea.strip()
                if len(linea_str) < 6:
                    continue
                m = patron_linea.match(linea_str)
                if m:
                    cod = (m.group(1) or "").strip()
                    desc = (m.group(2) or "").strip()
                    precio = limpiar_numero_moneda(m.group(3))
                    if desc and precio > 0 and not any(h in desc.lower() for h in ["subtotal", "total", "pagina", "fecha", "cuit"]):
                        filas.append(
                            {
                                "Codigo": cod,
                                "Articulo": desc,
                                "Precio_Lista": precio,
                                "Cant_Sugerida": 1,
                            }
                        )
    except Exception:
        pass
    return filas


def _normalizar_cabecera_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Si el Excel del proveedor tiene filas superiores de membrete/título/logo (muy común en mayoristas),
    detecta automáticamente en qué fila empieza realmente la tabla ('Código', 'Descripción', 'Precio', etc.)
    y limpia filas completamente vacías.
    """
    if df is None or df.empty:
        return df

    cols_str = [str(c).lower().strip() for c in df.columns]
    unnamed_count = sum(1 for c in cols_str if c.startswith("unnamed:") or c == "nan")

    palabras_cabecera = [
        "cod", "sku", "art", "desc", "prod", "det", "nombre", "item",
        "costo", "precio", "lista", "unitario", "neto", "importe", "valor", "venta"
    ]
    tiene_cabecera_clara = any(any(k in c for k in palabras_cabecera) for c in cols_str if not c.startswith("unnamed:"))

    if unnamed_count >= max(1, len(cols_str) // 2) and not tiene_cabecera_clara:
        max_scan = min(15, len(df))
        mejor_fila = None
        mejor_puntaje = 0
        for r_idx in range(max_scan):
            valores_fila = [limpiar_texto_celda(v).lower() for v in df.iloc[r_idx].values]
            puntaje = sum(
                1 for val in valores_fila if val and any(k in val for k in palabras_cabecera)
            )
            if puntaje > mejor_puntaje and puntaje >= 2:
                mejor_puntaje = puntaje
                mejor_fila = r_idx

        if mejor_fila is not None:
            nuevas_cols = [
                limpiar_texto_celda(v) or f"Columna_{i+1}"
                for i, v in enumerate(df.iloc[mejor_fila].values)
            ]
            df = df.iloc[mejor_fila + 1 :].copy()
            df.columns = nuevas_cols

    df = df.dropna(how="all").reset_index(drop=True)
    return df


def _leer_csv_argentino(ruta_archivo: Path) -> pd.DataFrame:
    """Soporta CSVs guardados desde Excel en español (separados por ';' o ',' y codificados en UTF-8 o Latin-1)."""
    for enc in ("utf-8-sig", "latin-1", "cp1252"):
        for sep in (None, ";", ","):
            try:
                if sep is None:
                    df = pd.read_csv(ruta_archivo, sep=None, engine="python", encoding=enc)
                else:
                    df = pd.read_csv(ruta_archivo, sep=sep, encoding=enc)
                if df is not None and len(df.columns) >= 2:
                    return _normalizar_cabecera_dataframe(df)
            except Exception:
                continue
    return _normalizar_cabecera_dataframe(pd.read_csv(ruta_archivo, encoding="latin-1"))


def inspeccionar_hojas_excel(ruta_archivo: Path) -> List[str]:
    """Retorna la lista de nombres de hojas si el archivo es un Excel (.xlsx, .xls)."""
    sufijo = ruta_archivo.suffix.lower()
    if sufijo in (".xlsx", ".xlsm", ".xltx"):
        try:
            from openpyxl import load_workbook
            wb = load_workbook(ruta_archivo, read_only=True)
            sheets = list(wb.sheetnames)
            wb.close()
            return sheets
        except Exception:
            pass
    elif sufijo == ".xls":
        try:
            import xlrd
            wb = xlrd.open_workbook(ruta_archivo, on_demand=True)
            return list(wb.sheet_names())
        except Exception:
            pass
    return []


def cargar_lista_universal_a_dataframe(ruta_archivo: Path, nombre_hoja: Optional[str] = None) -> pd.DataFrame:
    """
    Lector Universal para Pestañas 1 y 2:
    Soporta Excel (.xlsx, .xls) con selección de hoja o combinación de todas las hojas (__TODAS__),
    CSV (.csv), Documentos PDF (.pdf) y Fotos de Facturas/Remitos (.jpg, .jpeg, .png, .webp).
    """
    sufijo = ruta_archivo.suffix.lower()
    if sufijo in (".xlsx", ".xls"):
        if nombre_hoja and nombre_hoja == "__TODAS__":
            dict_dfs = pd.read_excel(ruta_archivo, sheet_name=None)
            dfs_limpios = []
            for _, df_sub in dict_dfs.items():
                if df_sub is not None and not df_sub.empty:
                    df_sub_norm = _normalizar_cabecera_dataframe(df_sub)
                    if len(df_sub_norm.columns) >= 2:
                        dfs_limpios.append(df_sub_norm)
            if dfs_limpios:
                return pd.concat(dfs_limpios, ignore_index=True)
            return _normalizar_cabecera_dataframe(pd.read_excel(ruta_archivo))
        elif nombre_hoja:
            df_raw = pd.read_excel(ruta_archivo, sheet_name=nombre_hoja)
            return _normalizar_cabecera_dataframe(df_raw)
        else:
            dict_dfs = pd.read_excel(ruta_archivo, sheet_name=None)
            if len(dict_dfs) > 1:
                dfs_limpios = []
                for _, df_sub in dict_dfs.items():
                    if df_sub is not None and not df_sub.empty:
                        df_sub_norm = _normalizar_cabecera_dataframe(df_sub)
                        if len(df_sub_norm.columns) >= 2:
                            dfs_limpios.append(df_sub_norm)
                if dfs_limpios:
                    return pd.concat(dfs_limpios, ignore_index=True)
            df_raw = pd.read_excel(ruta_archivo)
            return _normalizar_cabecera_dataframe(df_raw)

    if sufijo == ".csv":
        return _leer_csv_argentino(ruta_archivo)

    api_key = obtener_config("gemini_api_key", "")

    if sufijo == ".pdf":
        # 1. Intentar primero con Visión IA de Gemini si hay API Key configurada
        if api_key:
            filas_ia = _extraer_tabla_con_gemini_vision(ruta_archivo, "application/pdf", api_key)
            if filas_ia:
                return pd.DataFrame(filas_ia)
        # 2. Extractor local pypdf para PDFs con texto
        filas_local = _extraer_tabla_pdf_local(ruta_archivo)
        if filas_local:
            return pd.DataFrame(filas_local)
        raise ValueError(
            "No se pudieron extraer artículos de este PDF. Si es un PDF escaneado como imagen, configurá tu API Key de Google Gemini arriba en '✨ Configurar IA'."
        )

    if sufijo in (".jpg", ".jpeg", ".png", ".webp"):
        if not api_key:
            raise ValueError(
                "Para leer fotos de facturas o remitos con Visión Artificial, primero ingresá tu API Key de Google Gemini en el botón superior '✨ Configurar IA (Gemini)'."
            )
        mime_map = {
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".png": "image/png",
            ".webp": "image/webp",
        }
        filas_foto = _extraer_tabla_con_gemini_vision(ruta_archivo, mime_map[sufijo], api_key)
        if filas_foto:
            return pd.DataFrame(filas_foto)
        raise ValueError("No se pudieron detectar renglones de precios claros en la imagen subida.")

    return pd.read_excel(ruta_archivo)


# =====================================================================
# 5. PESTAÑA 1: PROCESADOR ACTUALIZADOR ENTERPRISE
# =====================================================================

def procesar_actualizacion_enterprise(
    ruta_catalogo_cliente: Path,
    ruta_lista_proveedor: Path,
    nombre_proveedor: str = "PROVEEDOR_GENERAL",
    descuento_1: float = 0.0,
    descuento_2: float = 0.0,
    iva_porc: float = 21.0,
    flete_porc: float = 0.0,
    modo_margen: str = "RESPETAR_EXCEL",  # 'RESPETAR_EXCEL' o 'FIJO'
    margen_fijo_porc: float = 45.0,
    modo_redondeo: str = "2_DECIMALES",
    umbral_alerta_porc: float = 35.0,
    usar_ia_gemini: bool = True,
    hoja_catalogo: Optional[str] = None,
    hoja_proveedor: Optional[str] = None,
    reglas_descuento_marcas: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Cruza el Excel del comerciante con la lista nueva del proveedor usando las 3 capas,
    hace backup automático, detecta alertas rojas de subas/bajas bruscas y genera el Excel actualizado.
    Soporta selección de hoja específica o unión de todas las hojas (__TODAS__).
    """
    # 1. Backup automático intocable antes de tocar un solo número
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    nombre_backup = f"BACKUP_{timestamp}_{ruta_catalogo_cliente.name}"
    ruta_backup = BACKUPS_DIR / nombre_backup
    shutil.copy2(ruta_catalogo_cliente, ruta_backup)

    df_cat = cargar_lista_universal_a_dataframe(ruta_catalogo_cliente, hoja_catalogo)
    df_prov = cargar_lista_universal_a_dataframe(ruta_lista_proveedor, hoja_proveedor)

    cols_cat = detectar_columnas_excel(df_cat)
    cols_prov = detectar_columnas_excel(df_prov)

    col_cod_cat = cols_cat["codigo"]
    col_desc_cat = cols_cat["descripcion"]
    col_costo_cat = cols_cat["precio_costo"]
    col_margen_cat = cols_cat["margen"]
    col_venta_cat = cols_cat["precio_venta"]

    col_cod_prov = cols_prov["codigo"]
    col_desc_prov = cols_prov["descripcion"]
    col_precio_prov = cols_prov["precio_costo"] or cols_prov["precio_venta"]
    col_dto_prov = cols_prov.get("descuento")
    reglas_dto_dict = parsear_reglas_descuento(reglas_descuento_marcas)

    # Indexar catálogo del cliente
    catalogo_por_codigo: Dict[str, int] = {}
    lista_catalogo_info: List[Dict[str, Any]] = []
    for idx, row in df_cat.iterrows():
        cod = limpiar_texto_celda(row[col_cod_cat]) if col_cod_cat else ""
        if not cod:
            cod = f"FILA-{idx+1}"
        desc = limpiar_texto_celda(row[col_desc_cat]) if col_desc_cat else ""
        costo_c = limpiar_numero_moneda(row[col_costo_cat]) if col_costo_cat else 0.0
        venta_c = limpiar_numero_moneda(row[col_venta_cat]) if col_venta_cat else 0.0
        if not desc and costo_c <= 0 and venta_c <= 0:
            continue
        catalogo_por_codigo[cod.upper()] = idx
        lista_catalogo_info.append({"idx": idx, "codigo": cod, "descripcion": desc})

    memoria = consultar_memoria_proveedor(nombre_proveedor)

    # Recorrer lista del proveedor y emparejar en 3 capas
    emparejados_por_idx_cat: Dict[int, Dict[str, Any]] = {}
    pendientes_ia: List[Dict[str, Any]] = []

    for _, prow in df_prov.iterrows():
        cod_p = limpiar_texto_celda(prow[col_cod_prov]) if col_cod_prov else ""
        desc_p = limpiar_texto_celda(prow[col_desc_prov]) if col_desc_prov else ""
        precio_p = limpiar_numero_moneda(prow[col_precio_prov]) if col_precio_prov else 0.0
        if precio_p <= 0 or (not cod_p and not desc_p):
            continue

        dto_p_fila = limpiar_numero_moneda(prow[col_dto_prov]) if col_dto_prov else 0.0
        dto_p_marca = 0.0
        if reglas_dto_dict and desc_p:
            desc_p_u = desc_p.upper()
            for rk, rv in reglas_dto_dict.items():
                if rk in desc_p_u:
                    dto_p_marca = rv
                    break

        clave_mem = f"{cod_p}|{desc_p}".upper()

        # CAPA 3: ¿Ya está en la Memoria Eterna SQLite de este proveedor?
        if clave_mem in memoria:
            cod_cat_guardado = memoria[clave_mem]["codigo_catalogo"].upper()
            if cod_cat_guardado in catalogo_por_codigo:
                idx_cat = catalogo_por_codigo[cod_cat_guardado]
                emparejados_por_idx_cat[idx_cat] = {
                    "cod_prov": cod_p,
                    "desc_prov": desc_p,
                    "precio_lista_prov": precio_p,
                    "descuento_prov_fila": dto_p_fila,
                    "descuento_marca_regla": dto_p_marca,
                    "metodo_cruce": "Memoria Inteligente (Automático)",
                    "confianza": 100,
                }
                continue

        # CAPA 1A: Cruce exacto por Código / SKU
        if cod_p and cod_p.upper() in catalogo_por_codigo:
            idx_cat = catalogo_por_codigo[cod_p.upper()]
            cat_row = df_cat.loc[idx_cat]
            guardar_emparejamiento_memoria(
                nombre_proveedor,
                clave_mem,
                desc_p,
                str(cat_row[col_cod_cat]),
                str(cat_row[col_desc_cat]),
                origen="SKU_EXACTO",
            )
            emparejados_por_idx_cat[idx_cat] = {
                "cod_prov": cod_p,
                "desc_prov": desc_p,
                "precio_lista_prov": precio_p,
                "descuento_prov_fila": dto_p_fila,
                "descuento_marca_regla": dto_p_marca,
                "metodo_cruce": "Código / SKU Exacto",
                "confianza": 100,
            }
            continue

        # CAPA 1B: Diccionario Inteligente de Abreviaturas Argentinas
        mejor_idx = None
        mejor_score = 0.0
        for item_cat in lista_catalogo_info:
            if item_cat["idx"] in emparejados_por_idx_cat:
                continue
            sc = calcular_similitud_capa1(desc_p, item_cat["descripcion"])
            if sc > mejor_score:
                mejor_score = sc
                mejor_idx = item_cat["idx"]

        if mejor_idx is not None and mejor_score >= 0.62:
            cat_row = df_cat.loc[mejor_idx]
            guardar_emparejamiento_memoria(
                nombre_proveedor,
                clave_mem,
                desc_p,
                str(cat_row[col_cod_cat]),
                str(cat_row[col_desc_cat]),
                origen="DICCIONARIO_ARG",
            )
            emparejados_por_idx_cat[mejor_idx] = {
                "cod_prov": cod_p,
                "desc_prov": desc_p,
                "precio_lista_prov": precio_p,
                "descuento_prov_fila": dto_p_fila,
                "descuento_marca_regla": dto_p_marca,
                "metodo_cruce": f"Diccionario Comercial ({int(mejor_score*100)}%)",
                "confianza": int(mejor_score * 100),
            }
        else:
            pendientes_ia.append(
                {
                    "id_prov": clave_mem,
                    "cod_prov": cod_p,
                    "desc_prov": desc_p,
                    "precio_lista_prov": precio_p,
                    "descuento_prov_fila": dto_p_fila,
                    "descuento_marca_regla": dto_p_marca,
                }
            )

    # CAPA 2: IA Google Gemini (Opcional, para los difíciles que no cruzaron en Capa 1)
    api_key = obtener_config("gemini_api_key", "")
    if usar_ia_gemini and api_key and pendientes_ia:
        candidatos_libres = [
            {"codigo": ic["codigo"], "descripcion": ic["descripcion"]}
            for ic in lista_catalogo_info
            if ic["idx"] not in emparejados_por_idx_cat
        ]
        lote_ia = [{"id_prov": p["id_prov"], "descripcion": p["desc_prov"]} for p in pendientes_ia]
        mapa_ia = emparejar_con_gemini_batch(lote_ia, candidatos_libres, api_key)

        for p in pendientes_ia:
            cod_cat_ia = mapa_ia.get(p["id_prov"])
            if cod_cat_ia and cod_cat_ia.upper() in catalogo_por_codigo:
                idx_cat = catalogo_por_codigo[cod_cat_ia.upper()]
                cat_row = df_cat.loc[idx_cat]
                guardar_emparejamiento_memoria(
                    nombre_proveedor,
                    p["id_prov"],
                    p["desc_prov"],
                    str(cat_row[col_cod_cat]),
                    str(cat_row[col_desc_cat]),
                    origen="GEMINI_IA",
                )
                emparejados_por_idx_cat[idx_cat] = {
                    "cod_prov": p["cod_prov"],
                    "desc_prov": p["desc_prov"],
                    "precio_lista_prov": p["precio_lista_prov"],
                    "descuento_prov_fila": p.get("descuento_prov_fila", 0.0),
                    "descuento_marca_regla": p.get("descuento_marca_regla", 0.0),
                    "metodo_cruce": "Lectura IA Gemini",
                    "confianza": 95,
                }

    # Calcular nuevos precios y armar tabla de resultados + actualizar DataFrame original
    descuentos = [descuento_1, descuento_2]
    filas_resultado: List[Dict[str, Any]] = []
    actualizados_count = 0
    alertas_rojas_count = 0

    df_salida = df_cat.copy()
    for col_num in [col_costo_cat, col_margen_cat, col_venta_cat]:
        if col_num and col_num in df_salida.columns:
            df_salida[col_num] = pd.to_numeric(df_salida[col_num], errors="coerce").astype(float)

    df_salida["Costo_Anterior"] = 0.0
    df_salida["Variacion_Porc"] = "0.0%"
    df_salida["Estado_Hoy"] = "SIN CAMBIOS"

    for idx, row in df_cat.iterrows():
        cod_c = limpiar_texto_celda(row[col_cod_cat]) if col_cod_cat else ""
        if not cod_c:
            cod_c = f"FILA-{idx+1}"
        desc_c = limpiar_texto_celda(row[col_desc_cat]) if col_desc_cat else ""
        costo_ant = limpiar_numero_moneda(row[col_costo_cat]) if col_costo_cat else 0.0
        venta_ant = limpiar_numero_moneda(row[col_venta_cat]) if col_venta_cat else 0.0

        if not desc_c and costo_ant <= 0 and venta_ant <= 0:
            continue

        margen_excel = limpiar_numero_moneda(row[col_margen_cat]) if col_margen_cat else 0.0

        # Flanco 1: Detección inteligente de margen
        if modo_margen == "RESPETAR_EXCEL":
            if margen_excel > 0:
                margen_aplicar = margen_excel
                tipo_margen_info = f"Excel ({margen_excel:.1f}%)"
            elif costo_ant > 0 and venta_ant > costo_ant:
                # Margen Histórico Implícito deducido de Costo y Venta anteriores
                margen_implicito = round(((venta_ant - costo_ant) / costo_ant) * 100.0, 2)
                margen_aplicar = margen_implicito
                tipo_margen_info = f"Histórico Implícito ({margen_implicito:.1f}%)"
            else:
                margen_aplicar = margen_fijo_porc
                tipo_margen_info = f"Por defecto ({margen_fijo_porc:.1f}%)"
        else:
            margen_aplicar = margen_fijo_porc
            tipo_margen_info = f"Fijo Global ({margen_fijo_porc:.1f}%)"

        df_salida.at[idx, "Costo_Anterior"] = round(costo_ant, 2)

        if idx in emparejados_por_idx_cat:
            emp = emparejados_por_idx_cat[idx]

            # Flanco 3: Descuentos en cascada (fila / marca / generales)
            descuentos_item = []
            if emp.get("descuento_prov_fila", 0.0) > 0:
                descuentos_item.append(emp["descuento_prov_fila"])
            elif emp.get("descuento_marca_regla", 0.0) > 0:
                descuentos_item.append(emp["descuento_marca_regla"])

            for d in descuentos:
                if d > 0:
                    descuentos_item.append(d)

            calculo = calcular_costo_y_venta_contable(
                precio_lista_proveedor=emp["precio_lista_prov"],
                descuentos_cascada=descuentos_item,
                iva_porc=iva_porc,
                flete_porc=flete_porc,
                margen_porc=margen_aplicar,
                modo_redondeo=modo_redondeo,
            )
            nuevo_costo = calculo["costo_real_limpio"]
            nueva_venta = calculo["precio_venta_final"]

            # Flanco 2: Cálculo de variación y alerta roja
            if costo_ant > 0:
                variacion_porc = round(((nuevo_costo - costo_ant) / costo_ant) * 100.0, 1)
                base_variacion = "Costo"
            elif venta_ant > 0:
                variacion_porc = round(((nueva_venta - venta_ant) / venta_ant) * 100.0, 1)
                base_variacion = "Venta Mostrador"
            else:
                variacion_porc = 0.0
                base_variacion = "N/A"

            alerta_roja = False
            motivo_alerta = ""
            if abs(variacion_porc) >= umbral_alerta_porc:
                alerta_roja = True
                alertas_rojas_count += 1
                if variacion_porc > 0:
                    if variacion_porc >= 40.0:
                        motivo_alerta = f"ALERTA SUBA BRUSCA (+{variacion_porc}% en {base_variacion}): Verificar si es Bulto/Caja vs Unidad o error en lista"
                    else:
                        motivo_alerta = f"ALERTA SUBA (+{variacion_porc}% en {base_variacion}): Verificar precio o presentación del proveedor"
                else:
                    motivo_alerta = f"ALERTA BAJA ({variacion_porc}% en {base_variacion}): Verificar si es Unidad vs Bulto o cambio de presentación"

            # Actualizar en el Excel de salida respetando las columnas originales del comerciante
            if col_costo_cat:
                df_salida.at[idx, col_costo_cat] = nuevo_costo
            else:
                df_salida.at[idx, "Costo_Nuevo_Proveedor"] = nuevo_costo

            if col_margen_cat and modo_margen == "FIJO":
                df_salida.at[idx, col_margen_cat] = margen_aplicar
            elif col_margen_cat and modo_margen == "RESPETAR_EXCEL":
                if pd.isna(df_salida.at[idx, col_margen_cat]) or df_salida.at[idx, col_margen_cat] == 0:
                    df_salida.at[idx, col_margen_cat] = margen_aplicar

            if col_venta_cat:
                df_salida.at[idx, col_venta_cat] = nueva_venta
            else:
                df_salida.at[idx, "Precio_Venta_Actualizado"] = nueva_venta

            signo = "+" if variacion_porc > 0 else ""
            df_salida.at[idx, "Variacion_Porc"] = f"{signo}{variacion_porc}%"
            df_salida.at[idx, "Estado_Hoy"] = (
                f"ALERTA ({signo}{variacion_porc}%)" if alerta_roja else f"ACTUALIZADO ({signo}{variacion_porc}%)"
            )

            actualizados_count += 1
            filas_resultado.append(
                {
                    "codigo": cod_c,
                    "articulo_catalogo": desc_c,
                    "articulo_proveedor": emp["desc_prov"],
                    "metodo_cruce": emp["metodo_cruce"],
                    "costo_anterior": round(costo_ant, 2),
                    "precio_lista_prov": round(emp["precio_lista_prov"], 2),
                    "descuentos_aplicados": descuentos_item,
                    "costo_nuevo_limpio": nuevo_costo,
                    "variacion_porc": variacion_porc,
                    "margen_porc": margen_aplicar,
                    "tipo_margen": tipo_margen_info,
                    "venta_anterior": round(venta_ant, 2),
                    "venta_nueva": nueva_venta,
                    "estado": "ALERTA_ROJA" if alerta_roja else "ACTUALIZADO",
                    "motivo_alerta": motivo_alerta,
                }
            )
        else:
            filas_resultado.append(
                {
                    "codigo": cod_c,
                    "articulo_catalogo": desc_c,
                    "articulo_proveedor": "— Sin cambios en esta lista (Huérfano / Otro proveedor) —",
                    "metodo_cruce": "Sin coincidencia en lista",
                    "costo_anterior": round(costo_ant, 2),
                    "precio_lista_prov": 0.0,
                    "costo_nuevo_limpio": round(costo_ant, 2),
                    "variacion_porc": 0.0,
                    "margen_porc": margen_aplicar,
                    "tipo_margen": tipo_margen_info,
                    "venta_anterior": round(venta_ant, 2),
                    "venta_nueva": round(venta_ant, 2),
                    "estado": "SIN_CAMBIOS",
                    "motivo_alerta": "Podés cotizarlo en vivo en la Pestaña 3 (Radar MercadoLibre)",
                }
            )

    nombre_salida = f"CATALOGO_ACTUALIZADO_{timestamp}.xlsx"
    ruta_salida = EXPORTADOS_DIR / nombre_salida

    hojas_orig = inspeccionar_hojas_excel(ruta_catalogo_cliente)
    es_multisheet = len(hojas_orig) > 1 and hoja_catalogo and hoja_catalogo != "__TODAS__" and hoja_catalogo in hojas_orig

    if es_multisheet:
        from openpyxl import load_workbook
        wb = load_workbook(ruta_catalogo_cliente)
        pos = hojas_orig.index(hoja_catalogo)
        del wb[hoja_catalogo]
        ws = wb.create_sheet(hoja_catalogo, pos)
        ws.append(list(df_salida.columns))
        for row_vals in df_salida.itertuples(index=False):
            ws.append(list(row_vals))
        wb.save(ruta_salida)
    else:
        df_salida.to_excel(ruta_salida, index=False)

    # Colorear el Excel de salida con OpenPyXL para que el comerciante vea marcados en verde los actualizados y en rojo las alertas
    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill

        wb = load_workbook(ruta_salida)
        ws = wb[hoja_catalogo] if (es_multisheet and hoja_catalogo in wb.sheetnames) else wb.active

        fill_header = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
        font_header = Font(color="FFFFFF", bold=True)
        fill_verde = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
        font_verde = Font(color="137333", bold=True)
        fill_rojo = PatternFill(start_color="FCE8E6", end_color="FCE8E6", fill_type="solid")
        font_rojo = Font(color="C5221F", bold=True)

        headers_map = {}
        for col_idx in range(1, ws.max_column + 1):
            cell_h = ws.cell(row=1, column=col_idx)
            cell_h.fill = fill_header
            cell_h.font = font_header
            headers_map[str(cell_h.value)] = col_idx

        col_estado_idx = headers_map.get("Estado_Hoy")
        col_venta_idx = headers_map.get(str(col_venta_cat)) or headers_map.get("Precio_Venta_Actualizado")
        col_costo_idx = headers_map.get(str(col_costo_cat))
        col_var_idx = headers_map.get("Variacion_Porc")

        if col_estado_idx:
            for row_idx in range(2, ws.max_row + 1):
                val_est = str(ws.cell(row=row_idx, column=col_estado_idx).value or "")
                if val_est.startswith("ALERTA"):
                    for c_i in range(1, ws.max_column + 1):
                        ws.cell(row=row_idx, column=c_i).fill = fill_rojo
                    ws.cell(row=row_idx, column=col_estado_idx).font = font_rojo
                elif val_est.startswith("ACTUALIZADO"):
                    for c_i in [col_costo_idx, col_venta_idx, col_var_idx, col_estado_idx]:
                        if c_i:
                            ws.cell(row=row_idx, column=c_i).fill = fill_verde
                            ws.cell(row=row_idx, column=c_i).font = font_verde

        wb.save(ruta_salida)
    except Exception:
        pass

    # Registrar en historial SQLite
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO historial_actualizaciones
        (fecha, proveedor, archivo_original, archivo_backup, archivo_salida, total_articulos, actualizados, alertas_rojas)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            nombre_proveedor,
            ruta_catalogo_cliente.name,
            nombre_backup,
            nombre_salida,
            len(df_cat),
            actualizados_count,
            alertas_rojas_count,
        ),
    )
    conn.commit()
    conn.close()

    return {
        "resumen": {
            "proveedor": nombre_proveedor,
            "total_catalogo": len(df_cat),
            "actualizados": actualizados_count,
            "sin_cambios": len(df_cat) - actualizados_count,
            "alertas_rojas": alertas_rojas_count,
            "archivo_backup": nombre_backup,
            "archivo_salida": nombre_salida,
        },
        "items": filas_resultado,
    }


def exportar_catalogo_personalizado_p1(
    nombre_backup: str,
    nombre_proveedor: str,
    items_seleccionados: List[Dict[str, Any]],
    modo_margen: str = "RESPETAR_EXCEL",
    margen_fijo_porc: float = 45.0,
    hoja_catalogo: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Genera un Excel de Catálogo donde ÚNICAMENTE se actualizan los artículos que el comerciante tildó.
    Los artículos desmarcados mantienen su costo y precio de venta original intacto.
    Además, si hay artículos con cantidad > 0, genera el Excel de Pedido para el proveedor.
    """
    ruta_backup = BACKUPS_DIR / nombre_backup
    if not ruta_backup.exists():
        raise FileNotFoundError(f"No se encontró el archivo de respaldo {nombre_backup}")

    df_cat = cargar_lista_universal_a_dataframe(ruta_backup, hoja_catalogo)
    cols_cat = detectar_columnas_excel(df_cat)
    col_cod = cols_cat["codigo"]
    col_desc = cols_cat["descripcion"]
    col_costo = cols_cat["precio_costo"]
    col_margen = cols_cat["margen"]
    col_venta = cols_cat["precio_venta"]

    mapa_sel = {}
    for it in items_seleccionados:
        if it.get("seleccionado", True):
            mapa_sel[str(it.get("codigo", "")).strip().upper()] = it

    df_salida = df_cat.copy()
    for col_num in [col_costo, col_margen, col_venta]:
        if col_num and col_num in df_salida.columns:
            df_salida[col_num] = pd.to_numeric(df_salida[col_num], errors="coerce").astype(float)

    df_salida["Costo_Anterior"] = 0.0
    df_salida["Variacion_Porc"] = "0.0%"
    df_salida["Estado_Hoy"] = "SIN CAMBIOS"

    pedidos_filas = []
    total_pedido = 0.0

    for idx, row in df_cat.iterrows():
        cod = limpiar_texto_celda(row[col_cod]) if col_cod else f"FILA-{idx+1}"
        desc = limpiar_texto_celda(row[col_desc]) if col_desc else ""
        costo_ant = limpiar_numero_moneda(row[col_costo]) if col_costo else 0.0
        venta_ant = limpiar_numero_moneda(row[col_venta]) if col_venta else 0.0
        margen_excel = limpiar_numero_moneda(row[col_margen]) if col_margen else 0.0

        if modo_margen == "RESPETAR_EXCEL":
            if margen_excel > 0:
                margen_aplicar = margen_excel
            elif costo_ant > 0 and venta_ant > costo_ant:
                margen_aplicar = round(((venta_ant - costo_ant) / costo_ant) * 100.0, 2)
            else:
                margen_aplicar = margen_fijo_porc
        else:
            margen_aplicar = margen_fijo_porc

        df_salida.at[idx, "Costo_Anterior"] = round(costo_ant, 2)

        cod_u = cod.strip().upper()
        if cod_u in mapa_sel:
            sel_info = mapa_sel[cod_u]
            nuevo_costo = float(sel_info.get("costo_nuevo_limpio", costo_ant))
            nueva_venta = float(sel_info.get("venta_nueva", venta_ant or nuevo_costo))
            variacion = float(sel_info.get("variacion_porc", 0.0))

            if col_costo:
                df_salida.at[idx, col_costo] = nuevo_costo
            else:
                df_salida.at[idx, "Costo_Nuevo_Proveedor"] = nuevo_costo

            if col_margen and modo_margen == "FIJO":
                df_salida.at[idx, col_margen] = margen_aplicar
            elif col_margen and modo_margen == "RESPETAR_EXCEL":
                if pd.isna(df_salida.at[idx, col_margen]) or df_salida.at[idx, col_margen] == 0:
                    df_salida.at[idx, col_margen] = margen_aplicar

            if col_venta:
                df_salida.at[idx, col_venta] = nueva_venta
            else:
                df_salida.at[idx, "Precio_Venta_Actualizado"] = nueva_venta

            signo = "+" if variacion > 0 else ""
            df_salida.at[idx, "Variacion_Porc"] = f"{signo}{variacion}%"
            df_salida.at[idx, "Estado_Hoy"] = f"ACTUALIZADO ({signo}{variacion}%)"

            cant = int(sel_info.get("cantidad", 0))
            if cant > 0:
                sub = round(nuevo_costo * cant, 2)
                total_pedido += sub
                pedidos_filas.append({
                    "Codigo": cod,
                    "Descripcion": sel_info.get("articulo_catalogo") or desc,
                    "Cantidad_Pedir": cant,
                    "Precio_Costo_Limpio": nuevo_costo,
                    "Subtotal_Estimado": sub
                })

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    nom_cat = f"CATALOGO_PERSONALIZADO_{timestamp}.xlsx"
    ruta_cat_salida = EXPORTADOS_DIR / nom_cat

    hojas_orig = inspeccionar_hojas_excel(ruta_backup)
    es_multi = len(hojas_orig) > 1 and hoja_catalogo and hoja_catalogo != "__TODAS__" and hoja_catalogo in hojas_orig

    if es_multi:
        from openpyxl import load_workbook
        wb = load_workbook(ruta_backup)
        pos = hojas_orig.index(hoja_catalogo)
        del wb[hoja_catalogo]
        ws = wb.create_sheet(hoja_catalogo, pos)
        ws.append(list(df_salida.columns))
        for r_v in df_salida.itertuples(index=False):
            ws.append(list(r_v))
        wb.save(ruta_cat_salida)
    else:
        df_salida.to_excel(ruta_cat_salida, index=False)

    nom_pedido = None
    if pedidos_filas:
        slug_p = re.sub(r"[^a-zA-Z0-9]+", "_", nombre_proveedor).strip("_")
        nom_pedido = f"PEDIDO_{slug_p}_{timestamp}.xlsx"
        pd.DataFrame(pedidos_filas).to_excel(EXPORTADOS_DIR / nom_pedido, index=False)

    return {
        "ok": True,
        "archivo_catalogo": nom_cat,
        "url_catalogo": f"/api/descargar/exportados/{nom_cat}",
        "archivo_pedido": nom_pedido,
        "url_pedido": f"/api/descargar/exportados/{nom_pedido}" if nom_pedido else None,
        "total_actualizados": len(mapa_sel),
        "total_items_pedido": len(pedidos_filas),
        "subtotal_pedido": round(total_pedido, 2),
    }


# =====================================================================
# 6. PESTAÑA 2: COMPARADOR DE PROVEEDORES ("DÓNDE COMPRAR MÁS BARATO HOY")
# =====================================================================

def comparar_listas_proveedores(
    listas_config: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """
    Recibe N proveedores, cada uno con:
      - ruta_excel: Path
      - nombre: str
      - descuento_porc: float
      - iva_porc: float
    Normaliza cada lista a "Costo Real Limpio", empareja los artículos equivalentes entre todos
    los proveedores, determina quién tiene el mejor precio en cada ítem, calcula el Ahorro Total
    en pesos ($) y genera los Excel de pedido separados por proveedor ganador.
    """
    catalogo_unificado: List[Dict[str, Any]] = []

    for p_idx, pconf in enumerate(listas_config):
        ruta = Path(pconf["ruta_excel"])
        nombre_prov = pconf["nombre"].strip()
        desc_1 = float(pconf.get("descuento_porc", 0.0))
        desc_2 = float(pconf.get("descuento_2_porc", 0.0))
        iva_porc = float(pconf.get("iva_porc", 0.0))

        df = cargar_lista_universal_a_dataframe(ruta, pconf.get("hoja"))
        cols = detectar_columnas_excel(df)
        c_cod = cols["codigo"]
        c_desc = cols["descripcion"]
        c_precio = cols["precio_costo"]

        # Detectar columna opcional de cantidad sugerida
        c_cant = None
        for col in df.columns:
            if any(k in str(col).lower() for k in ["cant", "pedir", "unid", "bulto"]):
                c_cant = col
                break

        for _, row in df.iterrows():
            cod = limpiar_texto_celda(row[c_cod]) if c_cod else ""
            desc = limpiar_texto_celda(row[c_desc]) if c_desc else ""
            precio_lista = limpiar_numero_moneda(row[c_precio]) if c_precio else 0.0
            cantidad = int(limpiar_numero_moneda(row[c_cant])) if c_cant else 1
            if cantidad <= 0:
                cantidad = 1
            if precio_lista <= 0 or (not cod and not desc):
                continue

            calc = calcular_costo_y_venta_contable(
                precio_lista_proveedor=precio_lista,
                descuentos_cascada=[desc_1, desc_2],
                iva_porc=iva_porc,
                flete_porc=0.0,
                margen_porc=0.0,
            )
            costo_limpio = calc["costo_real_limpio"]

            # Buscar si este artículo ya existe en el catálogo unificado
            item_existente = None

            # 1. Coincidencia exacta por Código / SKU (Prioridad absoluta)
            if cod:
                for item_u in catalogo_unificado:
                    if item_u.get("tiene_sku_real") and cod.upper() == str(item_u["sku"]).upper():
                        if nombre_prov not in item_u["ofertas"]:
                            item_existente = item_u
                        break

            # 2. Si no cruzó por SKU (o no tiene SKU), buscar por texto con Diccionario (solo ítems sin oferta de este proveedor)
            if item_existente is None and desc:
                mejor_score = 0.0
                mejor_item = None
                for item_u in catalogo_unificado:
                    if nombre_prov in item_u["ofertas"]:
                        continue
                    sc = calcular_similitud_capa1(desc, item_u["articulo"])
                    if sc > mejor_score and sc >= 0.72:
                        mejor_score = sc
                        mejor_item = item_u
                if mejor_item is not None:
                    item_existente = mejor_item

            if item_existente is None:
                item_existente = {
                    "sku": cod or f"ITEM-{len(catalogo_unificado)+1:03d}",
                    "tiene_sku_real": bool(cod),
                    "articulo": desc or cod,
                    "cantidad": cantidad,
                    "ofertas": {},
                }
                catalogo_unificado.append(item_existente)

            item_existente["ofertas"][nombre_prov] = {
                "precio_lista": round(precio_lista, 2),
                "costo_limpio": costo_limpio,
            }

    # Evaluar ganador por ítem y ahorro total
    filas_comparativa: List[Dict[str, Any]] = []
    pedidos_por_proveedor: Dict[str, List[Dict[str, Any]]] = {
        p["nombre"].strip(): [] for p in listas_config
    }

    ahorro_total_pedido = 0.0
    costo_total_optimizado = 0.0
    costo_total_peor_caso = 0.0

    for item in catalogo_unificado:
        ofertas = item["ofertas"]
        if not ofertas:
            continue

        precios_limpios = {prov: datos["costo_limpio"] for prov, datos in ofertas.items()}
        prov_ganador = min(precios_limpios, key=precios_limpios.get)
        mejor_costo = precios_limpios[prov_ganador]
        peor_costo = max(precios_limpios.values())
        promedio_costo = sum(precios_limpios.values()) / len(precios_limpios)

        cant = item["cantidad"]
        ahorro_item_unitario = round(peor_costo - mejor_costo, 2)
        ahorro_item_subtotal = round(ahorro_item_unitario * cant, 2)

        ahorro_total_pedido += ahorro_item_subtotal
        costo_total_optimizado += mejor_costo * cant
        costo_total_peor_caso += peor_costo * cant

        pedidos_por_proveedor[prov_ganador].append(
            {
                "SKU": item["sku"],
                "Articulo": item["articulo"],
                "Cantidad_a_Pedir": cant,
                "Costo_Limpio_Unitario": mejor_costo,
                "Subtotal_Estimado": round(mejor_costo * cant, 2),
                "Ahorro_vs_Mas_Caro": ahorro_item_subtotal,
            }
        )

        filas_comparativa.append(
            {
                "sku": item["sku"],
                "articulo": item["articulo"],
                "cantidad": cant,
                "ofertas": ofertas,
                "ganador": prov_ganador,
                "mejor_costo": mejor_costo,
                "peor_costo": round(peor_costo, 2),
                "promedio_costo": round(promedio_costo, 2),
                "ahorro_porc": round(((peor_costo - mejor_costo) / peor_costo) * 100.0, 1)
                if peor_costo > 0
                else 0.0,
                "ahorro_subtotal_pesos": ahorro_item_subtotal,
            }
        )

    # Exportar los Excel de pedidos separados por proveedor + Excel Maestro Comparativo Pintado
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archivos_pedidos: Dict[str, str] = {}
    for prov, items_ped in pedidos_por_proveedor.items():
        if items_ped:
            slug = re.sub(r"[^a-zA-Z0-9]+", "_", prov).strip("_")
            nom_archivo = f"PEDIDO_OPTIMIZADO_{slug}_{timestamp}.xlsx"
            ruta_ped = EXPORTADOS_DIR / nom_archivo
            pd.DataFrame(items_ped).to_excel(ruta_ped, index=False)
            archivos_pedidos[prov] = nom_archivo

    # Generar Excel Comparativo General con el precio más barato pintado en verde
    nombres_provs = [p["nombre"].strip() for p in listas_config]
    filas_excel_comp = []
    for fc in filas_comparativa:
        fila_ex = {
            "SKU": fc["sku"],
            "Articulo": fc["articulo"],
            "Cant_Pedido": fc["cantidad"],
        }
        for np_prov in nombres_provs:
            of = fc["ofertas"].get(np_prov)
            fila_ex[f"{np_prov} (Costo Final)"] = of["costo_limpio"] if of else None
        fila_ex["Proveedor_Mas_Barato"] = fc["ganador"]
        fila_ex["Mejor_Costo_Unitario"] = fc["mejor_costo"]
        fila_ex["Ahorro_en_el_Item_$"] = fc["ahorro_subtotal_pesos"]
        fila_ex["Ahorro_%"] = f"-{fc['ahorro_porc']}%"
        filas_excel_comp.append(fila_ex)

    nom_comparativa_gral = f"COMPARATIVA_COMPLETA_{timestamp}.xlsx"
    ruta_comp_gral = EXPORTADOS_DIR / nom_comparativa_gral
    pd.DataFrame(filas_excel_comp).to_excel(ruta_comp_gral, index=False)

    try:
        from openpyxl import load_workbook
        from openpyxl.styles import Font, PatternFill

        wb = load_workbook(ruta_comp_gral)
        ws = wb.active
        fill_header = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
        font_header = Font(color="FFFFFF", bold=True)
        fill_verde = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
        font_verde = Font(color="137333", bold=True)

        headers_map = {}
        for col_idx in range(1, ws.max_column + 1):
            c_h = ws.cell(row=1, column=col_idx)
            c_h.fill = fill_header
            c_h.font = font_header
            headers_map[str(c_h.value)] = col_idx

        col_ganador = headers_map.get("Proveedor_Mas_Barato")
        if col_ganador:
            for r_idx in range(2, ws.max_row + 1):
                ganador_nombre = str(ws.cell(row=r_idx, column=col_ganador).value or "")
                ws.cell(row=r_idx, column=col_ganador).fill = fill_verde
                ws.cell(row=r_idx, column=col_ganador).font = font_verde
                col_prov_ganador = headers_map.get(f"{ganador_nombre} (Costo Final)")
                if col_prov_ganador:
                    ws.cell(row=r_idx, column=col_prov_ganador).fill = fill_verde
                    ws.cell(row=r_idx, column=col_prov_ganador).font = font_verde

        wb.save(ruta_comp_gral)
    except Exception:
        pass

    return {
        "resumen": {
            "total_articulos_comparados": len(filas_comparativa),
            "proveedores_analizados": nombres_provs,
            "costo_total_comprando_al_mas_caro": round(costo_total_peor_caso, 2),
            "costo_total_compra_inteligente": round(costo_total_optimizado, 2),
            "ahorro_total_pesos": round(ahorro_total_pedido, 2),
            "archivo_comparativa_completa": nom_comparativa_gral,
            "archivos_pedidos_separados": archivos_pedidos,
        },
        "items": filas_comparativa,
    }


# =====================================================================
# 7. PESTAÑA 3: RADAR DE MERCADO EN VIVO + EL JUEZ INTELIGENTE (FILTRO IA)
# =====================================================================

PALABRAS_DESCARTE_REPUESTOS = [
    "repuesto", "repuestos", "tapon", "cebador", "ampolla", "pico vertedor",
    "carbones", "carbon", "inducido", "interruptor", "gatillo", "engranaje",
    "rotor", "estator", "carcasa", "caja vacia", "maletin vacio", "funda",
    "usado", "usada", "para reparar", "a reparar", "solo cuerpo", "sin bateria",
    "alquiler", "microfono", "sensor", "kit educativo", "kit inicio", "kit camara", "brazo robotico"
]

STOPWORDS_BUSQUEDA = {
    "de", "del", "la", "el", "los", "las", "con", "sin", "para", "por", "en", "y", "un", "una", "litro", "litros", "lt", "lts"
}


CONFIG_PAISES_RADAR = {
    "argentina": {
        "pais": "Argentina",
        "moneda": "Pesos Argentinos ($ ARS)",
        "mercado": "MercadoLibre Argentina (mercadolibre.com.ar) y comercios online de Argentina",
        "base_url": "https://listado.mercadolibre.com.ar/{slug}",
    },
    "mexico": {
        "pais": "México",
        "moneda": "Pesos Mexicanos ($ MXN)",
        "mercado": "MercadoLibre México (mercadolibre.com.mx), Amazon México y comercios online de México",
        "base_url": "https://listado.mercadolibre.com.mx/{slug}",
    },
    "espana": {
        "pais": "España",
        "moneda": "Euros (€ EUR)",
        "mercado": "Amazon España (amazon.es), Leroy Merlin, ManoMano y comercios de España",
        "base_url": "https://www.amazon.es/s?k={slug}",
    },
    "europa": {
        "pais": "España / Europa",
        "moneda": "Euros (€ EUR)",
        "mercado": "Amazon España (amazon.es), Leroy Merlin y comercios de Europa",
        "base_url": "https://www.amazon.es/s?k={slug}",
    },
    "europa_eur": {
        "pais": "España / Europa",
        "moneda": "Euros (€ EUR)",
        "mercado": "Amazon España (amazon.es), Leroy Merlin y comercios de Europa",
        "base_url": "https://www.amazon.es/s?k={slug}",
    },
    "chile": {
        "pais": "Chile",
        "moneda": "Pesos Chilenos ($ CLP)",
        "mercado": "MercadoLibre Chile (mercadolibre.cl), Falabella, Sodimac y comercios de Chile",
        "base_url": "https://listado.mercadolibre.cl/{slug}",
    },
    "colombia": {
        "pais": "Colombia",
        "moneda": "Pesos Colombianos ($ COP)",
        "mercado": "MercadoLibre Colombia (mercadolibre.com.co), Homecenter y comercios de Colombia",
        "base_url": "https://listado.mercadolibre.com.co/{slug}",
    },
    "peru": {
        "pais": "Perú",
        "moneda": "Soles Peruanos (S/ PEN)",
        "mercado": "MercadoLibre Perú (mercadolibre.com.pe), Sodimac y comercios de Perú",
        "base_url": "https://listado.mercadolibre.com.pe/{slug}",
    },
    "latam_usd": {
        "pais": "Internacional",
        "moneda": "Dólares Estadounidenses (US$)",
        "mercado": "Amazon y tiendas online de referencia en Dólares",
        "base_url": "https://www.amazon.com/s?k={slug}",
    },
}


def simplificar_consulta_para_busqueda(txt: str) -> str:
    """Extrae las palabras clave esenciales eliminando empaques, medidas redundantes y conectores."""
    if not txt:
        return ""
    c = re.sub(r"\(.*?\)", "", txt)
    c = re.sub(r"\[.*?\]", "", c)
    c = re.sub(r"\b(e\s+interruptor\s+termomagn[eé]tico|interruptor\s+termomagn[eé]tico)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b(fino\s+para\s+acero\s+inoxidable|para\s+acero\s+inoxidable)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b(arandela\s+vulcanizada|con\s+arandela|con\s+v[aá]lvula|y\s+salida\s+flexible)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b(cabeza\s+hexagonal|cabeza\s+redonda|cabeza\s+fresada|cabeza\s+plana)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b(caja|pack|bolsa|set|kit|blister)\s*(x|de)?\s*\d+\s*(u|un|unid|unidades)?\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b\d+\s*(u|un|unid|unidades|piezas|pzs)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\b(pulgadas|pulg|milimetros|mm|metros|mts|dorado|zincado|hexagonal|paso|rosca|amperes|din\s*3ka)\b", "", c, flags=re.IGNORECASE)
    c = re.sub(r"\s+", " ", c).strip()
    words = c.split()
    if len(words) > 5:
        return " ".join(words[:5])
    return c


def obtener_enlaces_marketplace(consulta_limpia: str, pais_id: str = "argentina") -> List[Dict[str, str]]:
    """Devuelve los accesos directos al marketplace y tiendas de referencia del país activo."""
    import urllib.parse
    q_enc = urllib.parse.quote(consulta_limpia)
    pais = (pais_id or "argentina").lower()

    if pais in ("argentina", "ar"):
        return [
            {"nombre": "Mercado Libre Argentina", "url": f"https://listado.mercadolibre.com.ar/{q_enc}", "tipo": "meli"},
            {"nombre": "Easy Argentina", "url": f"https://www.easy.com.ar/{q_enc}", "tipo": "easy"},
        ]
    elif pais in ("mexico", "mx"):
        return [
            {"nombre": "Mercado Libre México", "url": f"https://listado.mercadolibre.com.mx/{q_enc}", "tipo": "meli"},
            {"nombre": "Amazon México", "url": f"https://www.amazon.com.mx/s?k={q_enc}", "tipo": "amazon"},
            {"nombre": "The Home Depot México", "url": f"https://www.homedepot.com.mx/buscar?text={q_enc}", "tipo": "homedepot"},
        ]
    elif pais in ("colombia", "co"):
        return [
            {"nombre": "Mercado Libre Colombia", "url": f"https://listado.mercadolibre.com.co/{q_enc}", "tipo": "meli"},
            {"nombre": "Homecenter Colombia", "url": f"https://www.homecenter.com.co/homecenter-co/search?Ntt={q_enc}", "tipo": "homecenter"},
        ]
    elif pais in ("chile", "cl"):
        return [
            {"nombre": "Mercado Libre Chile", "url": f"https://listado.mercadolibre.cl/{q_enc}", "tipo": "meli"},
            {"nombre": "Sodimac Chile", "url": f"https://sodimac.falabella.com/sodimac-cl/search?Ntt={q_enc}", "tipo": "sodimac"},
        ]
    elif pais in ("peru", "pe"):
        return [
            {"nombre": "Mercado Libre Perú", "url": f"https://listado.mercadolibre.com.pe/{q_enc}", "tipo": "meli"},
            {"nombre": "Sodimac Perú", "url": f"https://sodimac.falabella.com.pe/sodimac-pe/search?Ntt={q_enc}", "tipo": "sodimac"},
        ]
    elif pais in ("espana", "es", "europa", "europa_eur"):
        return [
            {"nombre": "Amazon España", "url": f"https://www.amazon.es/s?k={q_enc}", "tipo": "amazon"},
            {"nombre": "Leroy Merlin España", "url": f"https://www.leroymerlin.es/search?q={q_enc}", "tipo": "leroy"},
            {"nombre": "ManoMano España", "url": f"https://www.manomano.es/busqueda/{q_enc}", "tipo": "manomano"},
        ]
    else:  # latam_usd o internacional
        return [
            {"nombre": "Amazon Internacional (US$)", "url": f"https://www.amazon.com/s?k={q_enc}", "tipo": "amazon"},
        ]


def _consultar_conector_gemini_google_search(
    consulta: str, api_key: str, pais_id: str = "argentina"
) -> List[Dict[str, Any]]:
    """
    Si el comerciante configuró su API Key de Google Gemini, utiliza Gemini con Google Search Grounding
    en tiempo real para buscar precios vigentes en el mercado y moneda local del país seleccionado.
    """
    if not api_key:
        return []

    cfg = CONFIG_PAISES_RADAR.get(str(pais_id or "argentina").lower(), CONFIG_PAISES_RADAR["argentina"])

    prompt = (
        f"Buscá precios reales vigentes hoy en {cfg['pais']} ({cfg['mercado']}) "
        f"en su moneda local ({cfg['moneda']}) para el producto: '{consulta}'.\n"
        "Devolvé ÚNICAMENTE un arreglo JSON con entre 5 y 10 publicaciones reales encontradas, con este formato exacto:\n"
        "[{\"titulo\": \"Nombre exacto de la publicación\", \"precio\": 12345.0, \"link\": \"https://...\", \"es_repuesto_o_accesorio\": false, \"motivo_descarte\": \"\"}]"
    )

    for modelo in ["gemini-2.5-flash", "gemini-2.0-flash"]:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={api_key.strip()}"
        try:
            resp = requests.post(
                url,
                json={
                    "contents": [{"parts": [{"text": prompt}]}],
                    "tools": [{"google_search": {}}],
                    "generationConfig": {"temperature": 0.1},
                },
                timeout=12,
            )
            if resp.status_code == 200:
                data = resp.json()
                texto = (
                    data.get("candidates", [{}])[0]
                    .get("content", {})
                    .get("parts", [{}])[0]
                    .get("text", "[]")
                )
                m = re.search(r"\[.*\]", texto, re.DOTALL)
                if m:
                    items = json.loads(m.group(0))
                    resultados = []
                    slug_ml = re.sub(r'\s+', '-', consulta.strip())
                    link_fallback = cfg["base_url"].format(slug=slug_ml)
                    for it in items:
                        pr = float(it.get("precio", 0) or 0)
                        if pr > 0 and it.get("titulo"):
                            resultados.append(
                                {
                                    "titulo": str(it["titulo"]),
                                    "precio": pr,
                                    "link": str(it.get("link") or link_fallback),
                                    "fuente": f"GEMINI_SEARCH_{cfg['pais'].upper()}",
                                    "descarte_ia": bool(it.get("es_repuesto_o_accesorio", False)),
                                    "motivo_ia": str(it.get("motivo_descarte") or ""),
                                }
                            )
                    if resultados:
                        return resultados
        except Exception:
            continue
    return []


def _extraer_resultados_mercadolibre_en_vivo(
    consulta: str, pais_id: str = "argentina"
) -> List[Dict[str, Any]]:
    """
    El Sabueso Local en Vivo (100% Datos Reales, CERO precios inventados):
    1) Si hay API Key de Gemini activa, consulta con Google Search Grounding en tiempo real para el país activo.
    2) Si es Argentina, consulta en paralelo catálogos nacionales abiertos de Argentina
       (TodoMicro, Fravega, Cetrogar, Naldo, Easy, Carrefour, Masonline, Jumbo) con filtrado estricto de relevancia.
    """
    from concurrent.futures import ThreadPoolExecutor
    from bs4 import BeautifulSoup
    import urllib.parse

    pais_clave = str(pais_id or "argentina").lower()
    resultados: List[Dict[str, Any]] = []
    api_key = obtener_config("gemini_api_key", "")
    if api_key:
        res_gemini = _consultar_conector_gemini_google_search(consulta, api_key, pais_id=pais_clave)
        if res_gemini:
            resultados.extend(res_gemini)

    # Preparar consulta normalizada para búsqueda y filtrado de relevancia
    c_simp = simplificar_consulta_para_busqueda(consulta)
    c_norm = normalizar_texto_argentino(c_simp or consulta).strip()
    palabras_clave = [
        p for p in re.findall(r"[a-z0-9]+", c_norm)
        if len(p) >= 2 and p not in STOPWORDS_BUSQUEDA
    ]
    query_limpia = " ".join(palabras_clave) if palabras_clave else consulta.strip()
    q_encoded = urllib.parse.quote(query_limpia)

    # Catálogos abiertos directos (para Argentina preserva 100% las fuentes nativas de Argentina)
    if pais_clave == "argentina" or not resultados:
        fuentes_vtex = [
            ("Fravega Argentina", f"https://www.fravega.com/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Cetrogar Argentina", f"https://www.cetrogar.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Naldo Argentina", f"https://www.naldo.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Easy Argentina", f"https://www.easy.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Carrefour Argentina", f"https://www.carrefour.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Masonline Argentina", f"https://www.masonline.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
            ("Jumbo Argentina", f"https://www.jumbo.com.ar/api/catalog_system/pub/products/search/{q_encoded}"),
        ]

        headers = {
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            ),
            "Accept": "application/json",
        }

        def consultar_vtex(tupla):
            nombre_tienda, url = tupla
            hallados = []
            try:
                r = requests.get(url, headers=headers, timeout=6)
                if r.status_code in (200, 206) and r.text.strip().startswith("["):
                    items = r.json()
                    for it in items[:15]:
                        titulo = it.get("productName", "").strip()
                        link = it.get("link", "")
                        ofertas = it.get("items", [{}])[0].get("sellers", [{}])[0].get("commertialOffer", {})
                        precio = float(ofertas.get("Price") or 0.0)
                        if titulo and precio > 0:
                            hallados.append(
                                {
                                    "titulo": f"{titulo} — {nombre_tienda}",
                                    "precio": round(precio, 2),
                                    "link": link or url,
                                    "fuente": nombre_tienda,
                                }
                            )
            except Exception:
                pass
            return hallados

        def consultar_todomicro():
            hallados = []
            try:
                url_tm = f"https://www.todomicro.com.ar/buscar?controller=search&s={q_encoded}"
                headers_html = {
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                        "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
                    ),
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                }
                r = requests.get(url_tm, headers=headers_html, timeout=6)
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, "html.parser")
                    for p in soup.select(".product-miniature"):
                        name_el = p.select_one(".product-name a")
                        price_el = p.select_one(".price")
                        if name_el and price_el:
                            tit = name_el.text.strip()
                            m_pr = re.search(r"([0-9]{1,3}(?:\.[0-9]{3})*(?:,[0-9]{2})?)", price_el.text)
                            if m_pr:
                                v_pr = float(m_pr.group(1).replace(".", "").replace(",", "."))
                                if v_pr > 0:
                                    hallados.append(
                                        {
                                            "titulo": f"{tit} — TodoMicro Argentina",
                                            "precio": round(v_pr, 2),
                                            "link": name_el.get("href", url_tm),
                                            "fuente": "TodoMicro Argentina",
                                        }
                                    )
            except Exception:
                pass
            return hallados

        with ThreadPoolExecutor(max_workers=8) as ex:
            fut_tm = ex.submit(consultar_todomicro)
            listas = list(ex.map(consultar_vtex, fuentes_vtex))
            for lst in listas:
                resultados.extend(lst)
            resultados.extend(fut_tm.result())

    # FILTRADO ESTRICTO DE RELEVANCIA: Evita falsos positivos por autocompletado o búsquedas difusas de las tiendas
    c_compact = re.sub(r"[^a-z0-9]", "", c_norm)
    filtrados_relevantes = []

    for item in resultados:
        t_norm = normalizar_texto_argentino(item["titulo"])
        t_compact = re.sub(r"[^a-z0-9]", "", t_norm)

        # 1. Coincidencia compacta para códigos/modelos (ej: 'esp 32' o 'esp32' en '...esp32...')
        if len(c_compact) >= 4 and c_compact in t_compact:
            filtrados_relevantes.append(item)
            continue

        # 2. Coincidencia por palabras clave completas
        if palabras_clave:
            coincidencias = sum(1 for pk in palabras_clave if re.search(r"\b" + re.escape(pk) + r"\b", t_norm))
            umbral = len(palabras_clave) if len(palabras_clave) <= 2 else (len(palabras_clave) - 1)
            if coincidencias >= umbral and coincidencias > 0:
                filtrados_relevantes.append(item)

    # Solo conservar los artículos realmente relevantes (NUNCA dejar pasar productos no relacionados si está vacío)
    resultados = filtrados_relevantes

    # Quitar duplicados por título + precio
    vistos = set()
    unicos = []
    for r in resultados:
        clave = (normalizar_texto_argentino(r["titulo"])[:45], round(r["precio"], -1))
        if clave not in vistos:
            vistos.add(clave)
            unicos.append(r)

    return unicos


def cotizar_radar_mercadolibre(
    consulta_articulo: str,
    comision_ml_porc: float = 25.0,
    pais_id: str = "argentina",
) -> Dict[str, Any]:
    """
    1. El Sabueso busca el artículo en vivo en el mercado local del país activo (CERO datos falsos).
    2. El Juez Inteligente descarta repuestos (tapones, ampollas, carbones, inducidos), accesorios,
       usados, medidas distintas o precios estadísticamente distorsionados.
    3. Calcula el Precio Promedio Limpio y le descuenta el % elegido por el comerciante.
       Si el comerciante elige 0%, el Precio Sugerido de Mostrador es exactamente igual al Promedio.
    """
    pais_clave = str(pais_id or "argentina").lower()
    brutos = _extraer_resultados_mercadolibre_en_vivo(consulta_articulo, pais_id=pais_clave)
    aprobados: List[Dict[str, Any]] = []
    descartados: List[Dict[str, Any]] = []

    consulta_norm = normalizar_texto_argentino(consulta_articulo)
    pide_un_litro = any(x in consulta_articulo.lower() for x in ["1 litro", "1l", "1 lt", "1lt", "1000ml", "1000 ml"])

    preliminares: List[Dict[str, Any]] = []
    for item in brutos:
        t_low = normalizar_texto_argentino(item["titulo"])
        motivo_desc = None

        if item.get("descarte_ia"):
            motivo_desc = item.get("motivo_ia") or "Descartado por Juez IA: Repuesto o accesorio"

        if not motivo_desc:
            for palabra_prohibida in PALABRAS_DESCARTE_REPUESTOS:
                if palabra_prohibida in t_low and palabra_prohibida not in consulta_norm:
                    motivo_desc = f"Descartado por Juez IA: Detectado '{palabra_prohibida}' (repuesto/accesorio)"
                    break

        if not motivo_desc:
            # Detección de combos / kits / packs múltiples cuando el usuario busca un artículo individual
            # Para bulonería/tornillería los blisters y packs son la unidad estándar de venta
            quiere_combo = any(w in consulta_norm for w in ["kit", "combo", "pack", "set", "lote", "juego", "tornillo", "bulon", "arandela", "tarugo", "clavo", "precinto", "grampa"])
            if not quiere_combo:
                patrones_combo = [
                    r"\bkit\b", r"\bcombo\b", r"\bset\s+de\b", r"\blote\b",
                    r"\bpack\s*x\s*\d+\b", r"\bx\s*[2-9]\b", r"\bx\s*\d{2,3}\b", r"\bpack\b"
                ]
                for pat in patrones_combo:
                    m_combo = re.search(pat, t_low)
                    if m_combo:
                        motivo_desc = f"Descartado por Juez IA: Detectado combo/kit/pack múltiple ('{m_combo.group(0)}') que distorsiona el precio individual"
                        break

        if not motivo_desc and pide_un_litro:
            if any(med in item["titulo"].lower() for med in ["0.65", "0,65", "650ml", "500ml", "0.5l", "750ml"]):
                motivo_desc = "Descartado por Juez IA: Capacidad/medida distinta a 1 Litro"

        if motivo_desc:
            descartados.append({**item, "motivo_descarte": motivo_desc})
        else:
            preliminares.append(item)

    if preliminares:
        precios_ordenados = sorted(x["precio"] for x in preliminares)
        mediana = precios_ordenados[len(precios_ordenados) // 2]
        for item in preliminares:
            if item["precio"] < (mediana * 0.40):
                descartados.append(
                    {
                        **item,
                        "motivo_descarte": "Descartado por Juez IA: Precio atípico muy bajo (accesorio/consumible)",
                    }
                )
            elif item["precio"] > (mediana * 2.20):
                descartados.append(
                    {
                        **item,
                        "motivo_descarte": "Descartado por Juez IA: Precio sobrevaluado / Kit múltiple que distorsiona el promedio",
                    }
                )
            else:
                aprobados.append(item)

    precios_aprobados = [x["precio"] for x in aprobados]
    promedio_ml = round(sum(precios_aprobados) / len(precios_aprobados), 2) if precios_aprobados else 0.0
    minimo_ml = round(min(precios_aprobados), 2) if precios_aprobados else 0.0
    maximo_ml = round(max(precios_aprobados), 2) if precios_aprobados else 0.0

    # Si el comerciante puso 0%, el precio sugerido es EXACTAMENTE igual al promedio sin redondeos raros
    if float(comision_ml_porc) == 0.0:
        precio_mostrador_final = promedio_ml
    else:
        precio_mostrador_sugerido = promedio_ml * (1.0 - (float(comision_ml_porc) / 100.0))
        precio_mostrador_final = round(precio_mostrador_sugerido, 2)

    n_aprob = len(aprobados)
    if n_aprob >= 4:
        nivel_confianza = "ALTA"
        mensaje_confianza = f"Confiabilidad Alta: Promedio respaldado por {n_aprob} comercios coincidentes."
    elif n_aprob in (2, 3):
        nivel_confianza = "MEDIA"
        mensaje_confianza = f"Confiabilidad Media: Muestra de {n_aprob} publicaciones. Precio de referencia orientativo."
    elif n_aprob == 1:
        nivel_confianza = "BAJA"
        mensaje_confianza = "Atención (Muestra Reducida): Solo se encontró 1 publicación en catálogo directo. Se sugiere usar como referencia preliminar o conectar la IA."
    else:
        nivel_confianza = "NULA"
        mensaje_confianza = "Sin coincidencias exactas en catálogos abiertos."

    cfg = CONFIG_PAISES_RADAR.get(pais_clave, CONFIG_PAISES_RADAR["argentina"])
    c_simplificada = simplificar_consulta_para_busqueda(consulta_articulo)
    enlaces_mercado = obtener_enlaces_marketplace(c_simplificada or consulta_articulo, pais_clave)

    return {
        "consulta": consulta_articulo,
        "consulta_simplificada": c_simplificada or consulta_articulo,
        "enlaces_marketplaces": enlaces_mercado,
        "pais_id": pais_clave,
        "pais_nombre": cfg["pais"],
        "moneda_esperada": cfg["moneda"],
        "comision_ml_aplicada_porc": comision_ml_porc,
        "promedio_mercadolibre": promedio_ml,
        "minimo_mercadolibre": minimo_ml,
        "maximo_mercadolibre": maximo_ml,
        "precio_mostrador_sugerido": precio_mostrador_final,
        "cantidad_aprobados": len(aprobados),
        "cantidad_descartados": len(descartados),
        "nivel_confianza": nivel_confianza,
        "mensaje_confianza": mensaje_confianza,
        "resultados_aprobados": aprobados,
        "resultados_descartados": descartados,
    }
