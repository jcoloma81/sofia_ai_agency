#!/usr/bin/env bash
cd "$(dirname "$0")"
PORT=8765
LOCAL_IP=$(hostname -I 2>/dev/null | awk '{print $1}')
[ -z "$LOCAL_IP" ] && LOCAL_IP="127.0.0.1"

# 1. Liberar el puerto si quedó tomado por una sesión previa
fuser -k $PORT/tcp >/dev/null 2>&1 || true
pkill -f "uvicorn.*$PORT" >/dev/null 2>&1 || true
sleep 0.5

echo "================================================================="
echo "🚀 Iniciando Súper Actualizador Pro (Edición Enterprise Local)..."
echo "💻 En esta computadora:                http://127.0.0.1:$PORT"
echo "📱 En tu Celular / Tablet (mismo Wi-Fi): http://$LOCAL_IP:$PORT"
echo "================================================================="
# Si no existe venv local, crearlo automáticamente para Linux
if [ ! -f "venv/bin/uvicorn" ]; then
    echo "📦 Preparando entorno de ejecución para Linux por primera vez..."
    python3 -m venv venv
    ./venv/bin/pip install -r requirements.txt
fi

(
  URL="http://127.0.0.1:$PORT"
  for i in $(seq 1 60); do
    if curl -s -o /dev/null "$URL" 2>/dev/null; then
      break
    fi
    sleep 0.3
  done
  if command -v google-chrome >/dev/null 2>&1; then
      google-chrome --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v chromium >/dev/null 2>&1; then
      chromium --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v chromium-browser >/dev/null 2>&1; then
      chromium-browser --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v brave-browser >/dev/null 2>&1; then
      brave-browser --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  elif command -v microsoft-edge >/dev/null 2>&1; then
      microsoft-edge --app="$URL" >/dev/null 2>&1 || xdg-open "$URL" >/dev/null 2>&1
  else
      xdg-open "$URL" >/dev/null 2>&1 || true
  fi
) &
./venv/bin/uvicorn app:app --host 0.0.0.0 --port $PORT
