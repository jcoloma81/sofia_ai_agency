#!/usr/bin/env python3
"""
Generador de Planillas Excel de Prueba (700 Artículos Reales de Ferretería, Pinturería, Electricidad, Sanitarios y Bulonería).
Crea en la carpeta `ejemplos_prueba/`:
  1. 1_mi_catalogo_ferreteria_actual.xlsx (3 Solapas: Buloneria_y_Herramientas [300], Pintureria_y_Quimicos [200], Sanitarios_y_Electricidad [200])
  2. 2_lista_nueva_proveedor_whatsapp.xlsx (2 Solapas: Buloneria_Mayorista [150], Herramientas_y_Discos [120] con Alertas Rojas)
  3. 3_mayorista_del_norte.xlsx (300 artículos - Lista Mayorista 1 para el Comparador)
  4. 4_distribuidora_oeste.xlsx (300 artículos - Lista Mayorista 2 para el Comparador)
  5. 5_importadora_central.xlsx (300 artículos - Lista Mayorista 3 para el Comparador)
"""

from pathlib import Path
import random
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
EJEMPLOS_DIR = BASE_DIR / "ejemplos_prueba"


def _generar_300_articulos_base(factor_escala: float = 1.0):
    rng = random.Random(20261022)
    items = []

    familias = [
        (
            "Bulonería",
            "Tornillo Autoperforante Hexagonal {med} pulgadas con arandela vulcanizada (x100u)",
            "Torn. Autoperf. Hex. {med} pulg c/arand. vulcanizada x100u",
            [
                "8 x 1/2", "8 x 3/4", "8 x 1", "8 x 1.25", "8 x 1.5",
                "10 x 1/2", "10 x 3/4", "10 x 1", "10 x 1.25", "10 x 1.5", "10 x 1.75", "10 x 2", "10 x 2.5",
                "12 x 3/4", "12 x 1", "12 x 1.25", "12 x 1.5", "12 x 2", "12 x 2.5", "12 x 3", "12 x 3.5",
                "14 x 1", "14 x 1.5", "14 x 2", "14 x 2.5", "14 x 3", "14 x 3.5", "14 x 4", "14 x 5", "14 x 6"
            ],
            4200.0, 60.0, 20,
        ),
        (
            "Bulonería",
            "Tornillo Fix Madera Dorado Phillips {med} milímetros Caja x 500 unidades",
            "Torn. Fix mad. ph. {med}mm cja x 500u",
            ["3.0 x 16", "3.0 x 20", "3.5 x 16", "3.5 x 20", "3.5 x 25", "3.5 x 30", "3.5 x 35", "3.5 x 40", "3.5 x 45", "3.5 x 50", "4.0 x 20", "4.0 x 25", "4.0 x 30", "4.0 x 35", "4.0 x 40", "4.0 x 45", "4.0 x 50", "4.0 x 60", "4.5 x 40", "4.5 x 50", "4.5 x 60", "4.5 x 70", "5.0 x 50", "5.0 x 60", "5.0 x 70", "5.0 x 80", "5.0 x 90", "5.0 x 100", "6.0 x 80", "6.0 x 100"],
            5800.0, 55.0, 15,
        ),
        (
            "Bulonería",
            "Bulón Cabeza Hexagonal Zincado Rosca Con Paso {med} pulgadas (x50u)",
            "Bulon cab. hex. zinc. {med} pulg x50u",
            ["1/4 x 1", "1/4 x 1.5", "1/4 x 2", "1/4 x 2.5", "1/4 x 3", "5/16 x 1", "5/16 x 1.5", "5/16 x 2", "5/16 x 2.5", "5/16 x 3", "3/8 x 1", "3/8 x 1.5", "3/8 x 2", "3/8 x 2.5", "3/8 x 3", "3/8 x 4", "1/2 x 1.5", "1/2 x 2", "1/2 x 2.5", "1/2 x 3", "1/2 x 3.5", "1/2 x 4", "1/2 x 5", "5/8 x 2", "5/8 x 3", "5/8 x 4", "3/4 x 3", "3/4 x 4", "3/4 x 5", "3/4 x 6"],
            9100.0, 55.0, 10,
        ),
        (
            "Abrasivos",
            "Disco de Corte Fino para Acero Inoxidable Tyrolit {med} milímetros",
            "Disco cto. fino p/acero inox Tyrolit {med}mm",
            ["115 x 1.0 x 22.2", "115 x 1.2 x 22.2", "115 x 1.6 x 22.2", "125 x 1.0 x 22.2", "125 x 1.6 x 22.2", "180 x 1.6 x 22.2", "180 x 2.0 x 22.2", "230 x 1.9 x 22.2", "230 x 2.0 x 22.2", "230 x 2.5 x 22.2", "300 x 3.0 x 25.4", "350 x 3.5 x 25.4", "115 x 6.0 Desbaste", "180 x 6.0 Desbaste", "230 x 6.0 Desbaste", "115 Flap Grano 40", "115 Flap Grano 60", "115 Flap Grano 80", "115 Flap Grano 120", "180 Flap Grano 60", "180 Flap Grano 80", "115 Diamantado Seg.", "115 Diamantado Cont.", "115 Diamantado Turbo", "180 Diamantado Seg.", "180 Diamantado Turbo", "230 Diamantado Seg.", "230 Diamantado Turbo", "115 Carburo Silicio", "180 Carburo Silicio"],
            1250.0, 50.0, 100,
        ),
        (
            "Electricidad",
            "Llave Térmica e Interruptor Termomagnético Sica {med} Amperes DIN 3kA",
            "Llave Term. Sica {med}A DIN 3kA",
            ["Unipolar 1x6", "Unipolar 1x10", "Unipolar 1x16", "Unipolar 1x20", "Unipolar 1x25", "Unipolar 1x32", "Unipolar 1x40", "Bipolar 2x6", "Bipolar 2x10", "Bipolar 2x15", "Bipolar 2x16", "Bipolar 2x20", "Bipolar 2x25", "Bipolar 2x32", "Bipolar 2x40", "Bipolar 2x50", "Bipolar 2x63", "Tripolar 3x16", "Tripolar 3x20", "Tripolar 3x25", "Tripolar 3x32", "Tripolar 3x40", "Tripolar 3x50", "Tripolar 3x63", "Tetrapolar 4x16", "Tetrapolar 4x20", "Tetrapolar 4x25", "Tetrapolar 4x32", "Tetrapolar 4x40", "Tetrapolar 4x63"],
            5400.0, 48.0, 20,
        ),
        (
            "Electricidad",
            "Rollo Cable Unipolar Normalizado IRAM {med} x 100 metros",
            "Rollo cable unip. norm. IRAM {med} x 100m",
            ["1.5mm Celeste", "1.5mm Marrón", "1.5mm Negro", "1.5mm Rojo", "1.5mm Verde/Amarillo", "2.5mm Celeste", "2.5mm Marrón", "2.5mm Negro", "2.5mm Rojo", "2.5mm Verde/Amarillo", "4.0mm Celeste", "4.0mm Marrón", "4.0mm Negro", "4.0mm Rojo", "4.0mm Verde/Amarillo", "6.0mm Celeste", "6.0mm Marrón", "6.0mm Negro", "6.0mm Verde/Amarillo", "10.0mm Marrón", "10.0mm Celeste", "10.0mm Negro", "10.0mm Verde/Amarillo", "Taller 2x1.5mm", "Taller 2x2.5mm", "Taller 3x1.5mm", "Taller 3x2.5mm", "Subterráneo 2x2.5mm", "Subterráneo 3x2.5mm", "Subterráneo 4x4.0mm"],
            32500.0, 38.0, 8,
        ),
        (
            "Sanitarios",
            "Caño y Accesorio Fusión Agua Fría/Caliente IPS {med} Tricapa",
            "Caño/Acc. fusion ag. fria/caliente IPS {med} tricapa",
            ["Caño 20mm x 4m", "Caño 25mm x 4m", "Caño 32mm x 4m", "Caño 40mm x 4m", "Caño 50mm x 4m", "Caño 63mm x 4m", "Codo 90° 20mm", "Codo 90° 25mm", "Codo 90° 32mm", "Codo 45° 20mm", "Codo 45° 25mm", "Te Normal 20mm", "Te Normal 25mm", "Te Normal 32mm", "Te Reducción 25x20mm", "Cupla Unión 20mm", "Cupla Unión 25mm", "Cupla Unión 32mm", "Codo Rosca Hembra 20x1/2", "Codo Rosca Hembra 25x1/2", "Codo Rosca Hembra 25x3/4", "Llave de Paso 20mm", "Llave de Paso 25mm", "Llave de Paso 32mm", "Válvula Esférica 20mm", "Válvula Esférica 25mm", "Válvula Esférica 32mm", "Unión Doble 20mm", "Unión Doble 25mm", "Curva Sobrepaso 20mm"],
            6800.0, 45.0, 25,
        ),
        (
            "Herramientas Manuales",
            "Llave Combinada Acero Cromo Vanadio Bahco {med} Profesional",
            "Llave comb. cr-v Bahco {med} prof.",
            ["6 milímetros", "7 milímetros", "8 milímetros", "9 milímetros", "10 milímetros", "11 milímetros", "12 milímetros", "13 milímetros", "14 milímetros", "15 milímetros", "16 milímetros", "17 milímetros", "18 milímetros", "19 milímetros", "20 milímetros", "21 milímetros", "22 milímetros", "23 milímetros", "24 milímetros", "25 milímetros", "26 milímetros", "27 milímetros", "28 milímetros", "30 milímetros", "32 milímetros", "1/4 pulgadas", "5/16 pulgadas", "3/8 pulgadas", "7/16 pulgadas", "1/2 pulgadas"],
            4900.0, 45.0, 12,
        ),
        (
            "Pinturería y Químicos",
            "Sellador, Adhesivo y Esmalte Sintético {med} Uso Profesional",
            "Sellador/Adh./Esmalte {med} uso prof.",
            ["Silicona Acética Transp. Suprabond 280ml", "Silicona Acética Negra Suprabond 280ml", "Silicona Acética Blanca Suprabond 280ml", "Silicona Neutra Gris 280ml", "Sellador Poliuretánico Gris Sikaflex 300ml", "Sellador Poliuretánico Blanco Sikaflex 300ml", "Sellador Poliuretánico Negro Sikaflex 300ml", "Adhesivo Contacto Poxiran 250g", "Adhesivo Contacto Poxiran 850g", "Adhesivo Epoxi Poxipol 10min Mediano", "Adhesivo Epoxi Poxipol 10min Grande", "Espuma Poliuretano Expandido 500ml", "Espuma Poliuretano Expandido 750ml", "Lubricante Multiuso WD-40 Aerosol 226g", "Lubricante Multiuso WD-40 Aerosol 311g", "Grasa Litio Cartucho 400g", "Convertidor de Óxido Negro 1 Litro", "Convertidor de Óxido Blanco 1 Litro", "Convertidor de Óxido Negro 4 Litros", "Aguarrás Mineral Botella 1 Litro", "Thinner Sello de Oro 1 Litro", "Antióxido Cromato Rojo 1 Litro", "Esmalte Sintético Brillante Blanco 1L", "Esmalte Sintético Brillante Negro 1L", "Esmalte Sintético Satinado Blanco 1L", "Látex Interior Blanco Mate 4 Litros", "Látex Interior Blanco Mate 10 Litros", "Látex Interior Blanco Mate 20 Litros", "Membrana Líquida Techos Blanca 4Kg", "Membrana Líquida Techos Blanca 20Kg"],
            7500.0, 50.0, 18,
        ),
        (
            "Herramientas Eléctricas y Soldadura",
            "Máquina e Insumo Industrial {med} Garantía Oficial",
            "Maq./Insumo ind. {med} gtia. of.",
            ["Amoladora Angular Bosch GWS 700 710W 115mm", "Amoladora Angular Bosch GWS 850 850W 115mm", "Amoladora Angular Makita GA4530 720W 115mm", "Amoladora Angular DeWalt DWE4020 800W 115mm", "Taladro Percutor Makita HP1630 710W 13mm", "Taladro Percutor Bosch GSB 13 RE 650W 13mm", "Taladro Percutor DeWalt DWD024 700W 13mm", "Rotomartillo SDS Plus Bosch GBH 2-26 800W", "Rotomartillo SDS Plus Makita HR2470 780W", "Sierra Circular Bosch GKS 150 1500W 184mm", "Sierra Caladora Bosch GST 680 500W", "Lijadora Orbital Makita BO4556 200W", "Termofusora Acqua System 800W Con Boquillas", "Soldadora Inverter Lusqtoff Iron 150 150A", "Soldadora Inverter Lusqtoff Iron 250 220A", "Máscara Soldar Fotosensible Lusqtoff ST-1X", "Electrodo Punta Azul Conarco 6013 2.00mm x 5Kg", "Electrodo Punta Azul Conarco 6013 2.50mm x 5Kg", "Electrodo Punta Azul Conarco 6013 3.25mm x 5Kg", "Electrodo Básico Conarco 7018 2.50mm x 5Kg", "Rollo Alambre Mig Flux 0.8mm x 1Kg", "Rollo Alambre Mig Macizo 0.8mm x 5Kg", "Hidrolavadora Kärcher K2 Compact 1400W 110Bar", "Hidrolavadora Kärcher K3 1600W 120Bar", "Compresor Aire 50 Litros 2.5HP Lusqtoff", "Cinta Métrica Stanley PowerLock 5m x 19mm", "Cinta Métrica Stanley Global Plus 8m x 25mm", "Juego Destornilladores Bahco Bahcofit 6 Piezas", "Pinza Universal Aislada 1000V Bahco 8 Pulgadas", "Alicate Corte Diagonal Bahco 7 Pulgadas"],
            68000.0, 40.0, 4,
        ),
    ]

    contador = 1
    for rubro, plantilla_cat, plantilla_prov, variantes, costo_base, margen_base, cant_ped in familias:
        for i, var in enumerate(variantes):
            codigo = f"FER-{contador:03d}"
            factor = 0.75 + (i * 0.08) + rng.uniform(-0.03, 0.05)
            costo_actual = round(costo_base * factor * factor_escala, 2)
            margen = float(margen_base)
            venta_actual = round(costo_actual * (1.0 + margen / 100.0), 2)
            stock = rng.randint(3, 120)

            items.append(
                {
                    "id_num": contador,
                    "codigo": codigo,
                    "rubro": rubro,
                    "desc_cat": plantilla_cat.format(med=var),
                    "desc_prov": plantilla_prov.format(med=var),
                    "costo_actual": costo_actual,
                    "margen": margen,
                    "venta_actual": venta_actual,
                    "stock": stock,
                    "cant_ped": cant_ped,
                }
            )
            contador += 1

    return items[:300]


def _generar_200_articulos_pintureria(start_id=301, factor_escala: float = 1.0):
    rng = random.Random(20261023)
    items = []
    colores = ["Blanco", "Negro", "Gris", "Azul Marino", "Rojo Bermellón", "Verde Bosque", "Amarillo", "Marrón", "Cedro", "Roble"]
    medidas_esm = ["1 Litro", "4 Litros"]
    pinceles = ["N° 7 (1/2 pulg)", "N° 10 (3/4 pulg)", "N° 15 (1 pulg)", "N° 20 (1.5 pulg)", "N° 25 (2 pulg)", "N° 30 (2.5 pulg)", "N° 35 (3 pulg)", "N° 40 (4 pulg)"]
    lijas = ["60", "80", "100", "120", "150", "180", "220", "240", "280", "320", "360", "400", "500", "600"]
    cintas = ["12mm x 50m", "18mm x 50m", "24mm x 50m", "36mm x 50m", "48mm x 50m"]
    aerosoles = ["Negro Brillante", "Negro Mate", "Blanco Brillante", "Blanco Mate", "Gris Grafito", "Rojo Fuego", "Azul", "Alta Temp. Negro", "Cromado", "Dorado", "Barniz Transparente"]

    cur = start_id
    for col in colores:
        for med in medidas_esm:
            costo = (7200.0 if "1" in med else 25400.0) * factor_escala
            items.append({
                "Codigo": f"PIN-{cur:04d}",
                "Articulo": f"Esmalte Sintético Brillante {col} {med} Alba",
                "Rubro": "Pinturería",
                "Costo_Neto_Actual": round(costo * rng.uniform(0.96, 1.04), 2),
                "Margen_Porc": 45.0,
                "Precio_Venta_Actual": round(costo * 1.45, 2),
                "Stock": rng.randint(4, 25),
            })
            cur += 1

    for p in pinceles:
        for marca in ["El Galgo", "Cano"]:
            costo = (1350.0 + (cur % 8) * 320) * factor_escala
            items.append({
                "Codigo": f"PIN-{cur:04d}",
                "Articulo": f"Pincel Virola 1 Cerda Pura {p} {marca}",
                "Rubro": "Accesorios Pintura",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 50.0,
                "Precio_Venta_Actual": round(costo * 1.5, 2),
                "Stock": rng.randint(12, 45),
            })
            cur += 1

    for g in lijas:
        for tipo in ["Al Agua Doble A", "Tela Esmeril Metal"]:
            costo = (490.0 if "Agua" in tipo else 820.0) * factor_escala
            items.append({
                "Codigo": f"PIN-{cur:04d}",
                "Articulo": f"Lija {tipo} Grano {g} Hoja 230x280mm",
                "Rubro": "Lijas",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 60.0,
                "Precio_Venta_Actual": round(costo * 1.6, 2),
                "Stock": rng.randint(40, 150),
            })
            cur += 1

    for a in aerosoles:
        costo = 3950.0 * factor_escala
        items.append({
            "Codigo": f"PIN-{cur:04d}",
            "Articulo": f"Pintura en Aerosol Multiuso {a} 440cc Kuwait",
            "Rubro": "Aerosoles",
            "Costo_Neto_Actual": round(costo, 2),
            "Margen_Porc": 48.0,
            "Precio_Venta_Actual": round(costo * 1.48, 2),
            "Stock": rng.randint(10, 30),
        })
        cur += 1

    for c in cintas:
        for marca in ["Doblea", "Tacsa"]:
            costo = (1650.0 + (cur % 5) * 380) * factor_escala
            items.append({
                "Codigo": f"PIN-{cur:04d}",
                "Articulo": f"Cinta de Enmascarar Pintor {c} {marca}",
                "Rubro": "Cintas",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 50.0,
                "Precio_Venta_Actual": round(costo * 1.5, 2),
                "Stock": rng.randint(15, 60),
            })
            cur += 1

    while len(items) < 200:
        n = len(items) + 1
        costo_it = 4200.0 * (1 + (n % 4) * 0.4) * factor_escala
        items.append({
            "Codigo": f"PIN-{cur:04d}",
            "Articulo": f"Látex Interior Antihongo Alba Mate {n%10 + 1} Litros",
            "Rubro": "Pinturería",
            "Costo_Neto_Actual": round(costo_it, 2),
            "Margen_Porc": 45.0,
            "Precio_Venta_Actual": round(costo_it * 1.45, 2),
            "Stock": rng.randint(5, 20),
        })
        cur += 1

    return items[:200]


def _generar_200_articulos_sanitarios_electricidad(start_id=501, factor_escala: float = 1.0):
    rng = random.Random(20261024)
    items = []
    diam_pvc = ["110mm", "63mm", "50mm", "40mm"]
    piezas_pvc = ["Caño Cloacal 4m", "Codo 90°", "Codo 45°", "Cupla Deslizante", "Ramal 90°", "Pileta Patio 3 Entradas", "Sopapa Pileta"]
    focos = ["Foco LED 9W Luz Fría", "Foco LED 9W Luz Cálida", "Foco LED 12W Luz Fría", "Foco LED 12W Luz Cálida", "Foco LED 15W Alta Potencia", "Reflector LED 30W Exterior IP65", "Reflector LED 50W Exterior IP65", "Reflector LED 100W Exterior IP65", "Plafón LED Embutir Redondo 18W", "Panel LED 60x60 40W"]
    modulos = ["Bastidor 3 Módulos", "Tapa Rectangular Blanca", "Módulo Tomacorriente 10A", "Módulo Interruptor Punto 10A", "Módulo Combinación 10A", "Módulo Ciego Blanco", "Caja Rectangular Chapa 10x5", "Caja Octogonal Chica Chapa"]
    canillas = ["Canilla Esférica Palanca 1/2 Jardín", "Canilla Esférica Palanca 3/4 Jardín", "Flexible Mallado Acero 1/2 x 40cm", "Flexible Mallado Acero 1/2 x 50cm", "Válvula Esférica Metálica Paso Total 1/2", "Válvula Esférica Metálica Paso Total 3/4", "Válvula Esférica Metálica Paso Total 1", "Cinta Teflón Alta Densidad 3/4 x 20m"]

    cur = start_id
    for d in diam_pvc:
        for p in piezas_pvc:
            costo = (8500.0 if "Caño" in p else 2100.0) * factor_escala
            items.append({
                "Codigo": f"SAN-{cur:04d}",
                "Articulo": f"{p} PVC Reforzado {d} Tigre",
                "Rubro": "Sanitarios PVC",
                "Costo_Neto_Actual": round(costo * rng.uniform(0.95, 1.05), 2),
                "Margen_Porc": 45.0,
                "Precio_Venta_Actual": round(costo * 1.45, 2),
                "Stock": rng.randint(8, 40),
            })
            cur += 1

    for f in focos:
        for marca in ["Philips", "Osram", "Sica"]:
            costo = (1800.0 + (cur % 7) * 900) * factor_escala
            items.append({
                "Codigo": f"ELE-{cur:04d}",
                "Articulo": f"{f} {marca} E27 220V",
                "Rubro": "Iluminación LED",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 50.0,
                "Precio_Venta_Actual": round(costo * 1.5, 2),
                "Stock": rng.randint(15, 60),
            })
            cur += 1

    for m in modulos:
        for marca in ["Jeluz Verona", "Sica Silight"]:
            costo = (950.0 + (cur % 6) * 280) * factor_escala
            items.append({
                "Codigo": f"ELE-{cur:04d}",
                "Articulo": f"{m} Línea {marca}",
                "Rubro": "Electricidad Hogar",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 55.0,
                "Precio_Venta_Actual": round(costo * 1.55, 2),
                "Stock": rng.randint(25, 100),
            })
            cur += 1

    for c in canillas:
        for marca in ["FV", "Genebre"]:
            costo = (4200.0 + (cur % 8) * 850) * factor_escala
            items.append({
                "Codigo": f"SAN-{cur:04d}",
                "Articulo": f"{c} {marca} Bronce Cromado",
                "Rubro": "Sanitarios y Grifería",
                "Costo_Neto_Actual": round(costo, 2),
                "Margen_Porc": 45.0,
                "Precio_Venta_Actual": round(costo * 1.45, 2),
                "Stock": rng.randint(6, 25),
            })
            cur += 1

    while len(items) < 200:
        n = len(items) + 1
        costo_it = 3600.0 * (1 + (n % 3) * 0.3) * factor_escala
        items.append({
            "Codigo": f"SAN-{cur:04d}",
            "Articulo": f"Sifón Doble Bajo Mesada Con Fuelle Extensible {n%5 + 1} Salida 50mm",
            "Rubro": "Sanitarios",
            "Costo_Neto_Actual": round(costo_it, 2),
            "Margen_Porc": 45.0,
            "Precio_Venta_Actual": round(costo_it * 1.45, 2),
            "Stock": rng.randint(8, 30),
        })
        cur += 1

    return items[:200]


def crear_excels_de_prueba(destino_dir=None, factor_escala=None) -> dict:
    if destino_dir is None:
        destino_dir = EJEMPLOS_DIR
    else:
        destino_dir = Path(destino_dir)
    destino_dir.mkdir(parents=True, exist_ok=True)

    if factor_escala is None:
        factor_escala = 1.0
        perfil_raiz = BASE_DIR / "perfil_regional.json"
        if perfil_raiz.exists():
            try:
                import json
                with open(perfil_raiz, "r", encoding="utf-8") as f:
                    factor_escala = float(json.load(f).get("factor_escala", 1.0))
            except Exception:
                factor_escala = 1.0
    else:
        factor_escala = float(factor_escala)

    ruta_catalogo = destino_dir / "1_mi_catalogo_ferreteria_actual.xlsx"
    ruta_lista_nueva = destino_dir / "2_lista_nueva_proveedor_whatsapp.xlsx"
    r_norte = destino_dir / "3_mayorista_del_norte.xlsx"
    r_oeste = destino_dir / "4_distribuidora_oeste.xlsx"
    r_central = destino_dir / "5_importadora_central.xlsx"

    # Si ya existen las 5 planillas de ejemplo, no recrearlas para un arranque ultra rapido
    if (
        ruta_catalogo.exists()
        and ruta_lista_nueva.exists()
        and r_norte.exists()
        and r_oeste.exists()
        and r_central.exists()
    ):
        return {
            "catalogo_actual_700_en_3_hojas": str(ruta_catalogo),
            "lista_nueva_proveedor_2_hojas": str(ruta_lista_nueva),
            "comparador_300": [str(r_norte), str(r_oeste), str(r_central)],
        }

    articulos_300 = _generar_300_articulos_base(factor_escala=factor_escala)
    articulos_pinto_200 = _generar_200_articulos_pintureria(301, factor_escala=factor_escala)
    articulos_sani_200 = _generar_200_articulos_sanitarios_electricidad(501, factor_escala=factor_escala)
    rng = random.Random(998877)

    # 1. Catálogo actual del comerciante (3 Solapas = 700 Artículos Reales)
    df_cat_base = pd.DataFrame([
        {
            "Codigo": a["codigo"],
            "Articulo": a["desc_cat"],
            "Rubro": a["rubro"],
            "Costo_Neto_Actual": a["costo_actual"],
            "Margen_Porc": a["margen"],
            "Precio_Venta_Actual": a["venta_actual"],
            "Stock": a["stock"],
        }
        for a in articulos_300
    ])

    df_cat_pinto = pd.DataFrame(articulos_pinto_200)
    df_cat_sani = pd.DataFrame(articulos_sani_200)

    with pd.ExcelWriter(ruta_catalogo, engine="openpyxl") as writer:
        df_cat_base.to_excel(writer, sheet_name="Buloneria_y_Herramientas", index=False)
        df_cat_pinto.to_excel(writer, sheet_name="Pintureria_y_Quimicos", index=False)
        df_cat_sani.to_excel(writer, sheet_name="Sanitarios_y_Electricidad", index=False)

    # 2. Lista nueva del proveedor (2 Solapas: Buloneria_Mayorista y Herramientas_y_Discos con Alertas Rojas)
    prov_buloneria = []
    prov_herramientas = []

    for idx, a in enumerate(articulos_300):
        if idx % 10 == 9:
            continue
        cod_prov = a["codigo"] if (idx % 3 != 1) else f"PRV-{a['id_num']:04d}"

        # 8 Alertas Rojas con suba brusca (+68%)
        if idx in (5, 32, 74, 118, 155, 201, 244, 288):
            precio_lista_sin_iva = round((a["costo_actual"] / 1.21) * 1.68, 2)
        else:
            aumento_normal = rng.uniform(1.04, 1.12)
            precio_lista_sin_iva = round((a["costo_actual"] / 1.21) * aumento_normal, 2)

        fila = {
            "Cod_Prov": cod_prov,
            "Detalle_Producto": a["desc_prov"],
            "Precio_Lista_Sin_IVA": precio_lista_sin_iva,
        }
        if idx < 160:
            prov_buloneria.append(fila)
        else:
            prov_herramientas.append(fila)

    with pd.ExcelWriter(ruta_lista_nueva, engine="openpyxl") as writer:
        pd.DataFrame(prov_buloneria).to_excel(writer, sheet_name="Buloneria_Mayorista", index=False)
        pd.DataFrame(prov_herramientas).to_excel(writer, sheet_name="Herramientas_y_Discos", index=False)

    # 3, 4 y 5. Tres listas para el Comparador de Proveedores (Solapa 2)
    prov_norte = []
    prov_oeste = []
    prov_central = []

    for idx, a in enumerate(articulos_300):
        base_sin_iva = a["costo_actual"] / 1.21
        if idx % 3 == 0:
            p_norte = round(base_sin_iva * 0.94, 2)
            p_oeste = round(base_sin_iva * 1.05, 2)
            p_central = round(base_sin_iva * 1.02, 2)
        elif idx % 3 == 1:
            p_norte = round(base_sin_iva * 1.06, 2)
            p_oeste = round(base_sin_iva * 0.93, 2)
            p_central = round(base_sin_iva * 1.03, 2)
        else:
            p_norte = round(base_sin_iva * 1.04, 2)
            p_oeste = round(base_sin_iva * 1.07, 2)
            p_central = round(base_sin_iva * 0.92, 2)

        prov_norte.append({
            "SKU": a["codigo"],
            "Descripcion": a["desc_cat"],
            "Precio_Lista": p_norte,
            "Cant_Sugerida": a["cant_ped"],
        })
        prov_oeste.append({
            "Codigo": a["codigo"],
            "Articulo": a["desc_prov"].upper(),
            "Costo": p_oeste,
            "Cant_Sugerida": a["cant_ped"],
        })
        prov_central.append({
            "Cod": a["codigo"],
            "Producto": a["desc_prov"],
            "Unitario": p_central,
            "Cant_Sugerida": a["cant_ped"],
        })

    pd.DataFrame(prov_norte).to_excel(r_norte, index=False)
    pd.DataFrame(prov_oeste).to_excel(r_oeste, index=False)
    pd.DataFrame(prov_central).to_excel(r_central, index=False)

    return {
        "catalogo_actual_700_en_3_hojas": str(ruta_catalogo),
        "lista_nueva_proveedor_2_hojas": str(ruta_lista_nueva),
        "comparador_300": [str(r_norte), str(r_oeste), str(r_central)],
    }


if __name__ == "__main__":
    archivos = crear_excels_de_prueba()
    print("✅ Planillas de 700 artículos con Multi-Sheets creadas con éxito!")
    for k, v in archivos.items():
        print(f"  - {k}: {v}")
