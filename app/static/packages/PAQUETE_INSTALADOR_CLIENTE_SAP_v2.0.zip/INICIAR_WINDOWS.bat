@echo off
title Super Actualizador Pro - Edicion Enterprise Local v2.0
cd /d "%~dp0"
set PORT=8765
echo =================================================================
echo   SUPER ACTUALIZADOR PRO - EDICION ENTERPRISE LOCAL v2.0
echo   100%% Local en tu PC - Tus datos nunca salen de tu comercio
echo =================================================================

:: 1. Detectar si Python ya esta instalado en el sistema o en rutas habituales
set "PYTHON_CMD="
where python >nul 2>nul && set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    where py >nul 2>nul && set "PYTHON_CMD=py"
)
if not defined PYTHON_CMD (
    if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
        set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python311\python.exe"
    ) else if exist "%ProgramFiles%\Python311\python.exe" (
        set "PYTHON_CMD=%ProgramFiles%\Python311\python.exe"
    ) else if exist "%ProgramFiles(x86)%\Python311\python.exe" (
        set "PYTHON_CMD=%ProgramFiles(x86)%\Python311\python.exe"
    )
)

:: 2. Si no se detecto Python, instalarlo automaticamente y sin friccion (Zero-Touch)
if not defined PYTHON_CMD (
    if exist "python-3.11.9-amd64.exe" (
        echo.
        echo =================================================================
        echo   [CONFIGURACION AUTOMATICA INICIAL]
        echo   Preparando componentes del sistema por unica vez...
        echo   (Se completa automaticamente en 15 segundos, por favor espera)
        echo =================================================================
        echo.
        start /wait "" "python-3.11.9-amd64.exe" /passive PrependPath=1 Include_test=0 InstallAllUsers=0
        timeout /t 2 /nobreak >nul
        
        if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
            set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python311\python.exe"
        ) else if exist "%ProgramFiles%\Python311\python.exe" (
            set "PYTHON_CMD=%ProgramFiles%\Python311\python.exe"
        ) else (
            where python >nul 2>nul && set "PYTHON_CMD=python"
            if not defined PYTHON_CMD (
                where py >nul 2>nul && set "PYTHON_CMD=py"
            )
        )
    )
)

:: 3. Verificacion final de seguridad
if not defined PYTHON_CMD (
    echo.
    echo =================================================================
    echo   [AVISO] No se detecto el motor de Python instalado.
    echo   Por favor ejecuta por unica vez "python-3.11.9-amd64.exe"
    echo   y asegurate de marcar abajo la casilla "Add python.exe to PATH".
    echo =================================================================
    echo.
    pause
    exit /b 1
)

:: 4. Configuracion de librerias locales offline si no existe el venv
if not exist "venv\Scripts\python.exe" (
    echo.
    echo [1/2] Creando entorno de ejecucion seguro...
    "%PYTHON_CMD%" -m venv venv
    if exist "venv\Scripts\pip.exe" (
        echo [2/2] Cargando librerias de alta velocidad...
        if exist "librerias_offline" (
            echo Modo Offline: Instalando paquetes locales sin consumir internet...
            venv\Scripts\pip.exe install --no-index --find-links=librerias_offline -r requirements.txt
        ) else (
            venv\Scripts\pip.exe install -r requirements.txt
        )
    ) else (
        echo Instalando librerias en Python base...
        if exist "librerias_offline" (
            "%PYTHON_CMD%" -m pip install --no-index --find-links=librerias_offline -r requirements.txt
        ) else (
            "%PYTHON_CMD%" -m pip install -r requirements.txt
        )
    )
)

:: 5. Iniciar la aplicacion y abrir el navegador solo
echo.
echo =================================================================
echo   Iniciando Súper Actualizador Pro en http://127.0.0.1:%PORT% ...
echo   (No cierres esta ventana mientras uses el programa)
echo =================================================================
echo.

start /b cmd /c "timeout /t 2 /nobreak >nul & start http://127.0.0.1:%PORT%"

if exist "venv\Scripts\python.exe" (
    venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port %PORT%
) else (
    "%PYTHON_CMD%" -m uvicorn app:app --host 127.0.0.1 --port %PORT%
)
pause
