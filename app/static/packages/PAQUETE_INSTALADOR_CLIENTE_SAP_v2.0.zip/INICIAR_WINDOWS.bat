@echo off
title Super Actualizador Pro - Edicion Enterprise Local v2.0
cd /d "%~dp0"
set PORT=8765

echo =======================================================================
echo   SUPER ACTUALIZADOR PRO - EDICION ENTERPRISE LOCAL v2.0
echo   100%% Local en tu PC - Tus datos nunca salen de tu comercio
echo =======================================================================
echo.

:: 0. Verificacion de extraccion: Asegurar que NO se ejecute dentro del ZIP
if not exist "motor_inteligente.py" (
    echo.
    echo =======================================================================
    echo   [AVISO CRITICO: DEBES EXTRAER EL ARCHIVO ZIP PRIMERO]
    echo.
    echo   Estas intentando abrir el programa adentro de la carpeta comprimida.
    echo   Para que funcione, primero debes EXTRAERLA:
    echo.
    echo   1. Hace CLIC DERECHO sobre el archivo descargado.
    echo   2. Hace clic en "Extraer todo..." y luego en "Extraer".
    echo   3. Entra a la NUEVA carpeta extraida que se creo en tu pantalla.
    echo   4. Hace doble clic en INICIAR_WINDOWS.bat.
    echo =======================================================================
    echo.
    pause
    exit /b 1
)

:: 1. Detectar si Python 3.11 ya esta instalado en rutas reales de disco
set "PYTHON_CMD="
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
    set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python311\python.exe"
) else if exist "%ProgramFiles%\Python311\python.exe" (
    set "PYTHON_CMD=%ProgramFiles%\Python311\python.exe"
) else if exist "%ProgramFiles(x86)%\Python311\python.exe" (
    set "PYTHON_CMD=%ProgramFiles(x86)%\Python311\python.exe"
)

:: 2. Si no esta en carpetas estandar, verificar si 'python' en PATH es real (y NO el alias vacio de Microsoft Store)
if not defined PYTHON_CMD (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=python"
    )
)

:: 3. Probar si el comando 'py' funciona con Python 3
if not defined PYTHON_CMD (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3"
    )
)

:: 4. Si no se detecto un Python real, instalarlo automaticamente sin intervencion (Zero-Touch)
if not defined PYTHON_CMD (
    if exist "python-3.11.9-amd64.exe" (
        echo =======================================================================
        echo   [CONFIGURACION AUTOMATICA INICIAL POR UNICA VEZ]
        echo   Preparando el motor del sistema en tu equipo...
        echo   (Se completa automaticamente en unos 20 segundos, no cierres esta ventana)
        echo =======================================================================
        echo.
        start /wait "" "python-3.11.9-amd64.exe" /passive PrependPath=1 Include_test=0 InstallAllUsers=0
        timeout /t 2 /nobreak >nul
        
        if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
            set "PYTHON_CMD=%LocalAppData%\Programs\Python\Python311\python.exe"
        ) else if exist "%ProgramFiles%\Python311\python.exe" (
            set "PYTHON_CMD=%ProgramFiles%\Python311\python.exe"
        ) else (
            python -c "import sys; sys.exit(0)" >nul 2>nul && set "PYTHON_CMD=python"
        )
    )
)

:: 5. Verificacion final de que el motor exista
if not defined PYTHON_CMD (
    echo.
    echo =======================================================================
    echo   [PASO UNICO REQUERIDO]
    echo   Para completar la configuracion en esta PC:
    echo   1. Hace doble clic en el instalador "python-3.11.9-amd64.exe"
    echo   2. IMPORTANTE: Marca abajo la casilla "Add python.exe to PATH"
    echo   3. Presiona "Install Now" y luego vuelve a ejecutar este archivo.
    echo =======================================================================
    echo.
    pause
    exit /b 1
)

:: 6. Configuracion del entorno venv local y librerias offline
if not exist "venv\Scripts\uvicorn.exe" (
    echo.
    echo [1/2] Preparando entorno de ejecucion seguro...
    if not exist "venv\Scripts\python.exe" (
        "%PYTHON_CMD%" -m venv venv
    )
    if exist "venv\Scripts\pip.exe" (
        echo [2/2] Cargando librerias de alta velocidad...
        if exist "librerias_offline" (
            echo Modo Offline: Instalando componentes locales sin consumir internet...
            venv\Scripts\pip.exe install --no-index --find-links=librerias_offline -r requirements.txt
        ) else (
            venv\Scripts\pip.exe install -r requirements.txt
        )
    ) else (
        echo Instalando componentes en el entorno base...
        if exist "librerias_offline" (
            "%PYTHON_CMD%" -m pip install --no-index --find-links=librerias_offline -r requirements.txt
        ) else (
            "%PYTHON_CMD%" -m pip install -r requirements.txt
        )
    )
)

:: 7. Liberar el puerto si quedo tomado por una sesion previa
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| findstr :%PORT% ^| findstr LISTENING') do (
    taskkill /f /pid %%a >nul 2>nul
)

:: 8. Iniciar la aplicacion y abrir el navegador exactamente cuando el servidor responda
echo.
echo =======================================================================
echo   Iniciando Súper Actualizador Pro en http://127.0.0.1:%PORT% ...
echo   (El navegador se abrira automaticamente cuando el sistema este listo)
echo   (No cierres esta ventana mientras uses el programa)
echo =======================================================================
echo.

:: Esperar a que el servidor web responda realmente antes de abrir Chrome (sin pantalla de error)
start /b cmd /c "powershell -WindowStyle Hidden -Command ""for ($i=0; $i -lt 40; $i++) { try { $res = Invoke-WebRequest -Uri 'http://127.0.0.1:%PORT%' -UseBasicParsing -TimeoutSec 1; if ($res.StatusCode -eq 200) { break } } catch { Start-Sleep -Milliseconds 500 } } Start-Process 'http://127.0.0.1:%PORT%'"" 2>nul || (timeout /t 5 /nobreak >nul & start http://127.0.0.1:%PORT%)"

if exist "venv\Scripts\python.exe" (
    venv\Scripts\python.exe -m uvicorn app:app --host 127.0.0.1 --port %PORT%
) else (
    "%PYTHON_CMD%" -m uvicorn app:app --host 127.0.0.1 --port %PORT%
)

echo.
echo =======================================================================
echo   El servidor se ha detenido.
echo =======================================================================
pause
