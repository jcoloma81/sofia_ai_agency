@echo off
title Crear Acceso Directo en el Escritorio
cd /d "%~dp0"
echo Creando acceso directo en el Escritorio...

set "TARGET_LAUNCHER=INICIAR_WINDOWS.bat"
if exist "INICIAR_SILENCIOSO.vbs" set "TARGET_LAUNCHER=INICIAR_SILENCIOSO.vbs"

powershell -NoProfile -ExecutionPolicy Bypass -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\Super Actualizador Pro.lnk'); $Shortcut.TargetPath = '%~dp0' + '%TARGET_LAUNCHER%'; $Shortcut.WorkingDirectory = '%~dp0'; $Shortcut.WindowStyle = 7; $Shortcut.Description = 'Super Actualizador Pro - Edicion Enterprise Local v2.0'; $Shortcut.Save()"

if %ERRORLEVEL% equ 0 (
    echo.
    echo =================================================================
    echo   [LISTO] Acceso directo creado en tu Escritorio:
    echo   "Super Actualizador Pro.lnk"
    echo =================================================================
) else (
    echo.
    echo No se pudo crear automaticamente. Podes hacer clic derecho en
    echo INICIAR_WINDOWS.bat y elegir "Enviar a -> Escritorio (crear acceso directo)".
)
echo.
pause
