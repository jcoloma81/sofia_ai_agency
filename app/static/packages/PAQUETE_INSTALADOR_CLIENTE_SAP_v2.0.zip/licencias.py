"""
Sistema de Candado Comercial por Hardware ID y Licencias por Niveles
para Súper Actualizador Pro (Edición Enterprise Local).

Niveles soportados:
- BASE: Destraba Pestaña 1 ilimitada; Pestañas 2 y 3 en modo "Demo de 3 pruebas gratis".
- FULL_PRO: Destraba todas las Pestañas de forma ilimitada y permanente.
- DEMO_7_DIAS: Destraba todas las Pestañas por 7 días corridos desde la emisión.
"""

import base64
import hashlib
import hmac
import json
import os
import platform
import re
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, Optional

# Secreto maestro de firma (solo lo conoce tu generador_licencias.py y el validador interno)
_MASTER_SECRET = b"SUPER_ACTUALIZADOR_PRO_ENTERPRISE_2026_MASTER_KEY_#9981"

BASE_DIR = Path(__file__).resolve().parent
LICENSE_FILE = BASE_DIR / "licencia_activa.json"
USAGE_FILE = BASE_DIR / "estado_uso.json"


def obtener_hardware_id() -> str:
    """
    Obtiene una huella única y estable de la PC del comerciante (Windows / Linux / Mac)
    y la formatea como: SAP-XXXX-XXXX-XXXX
    """
    componentes = []
    # 1. Node / Hostname + Arquitectura
    componentes.append(platform.node() or "PC")
    componentes.append(platform.machine() or "x86_64")

    # 2. Machine ID del sistema operativo si existe, o MAC address física
    machine_id_leido = ""
    for ruta in ["/etc/machine-id", "/var/lib/dbus/machine-id"]:
        try:
            if os.path.exists(ruta):
                with open(ruta, "r", encoding="utf-8") as f:
                    machine_id_leido = f.read().strip()
                if machine_id_leido:
                    break
        except Exception:
            pass

    if machine_id_leido:
        componentes.append(machine_id_leido)
    else:
        componentes.append(str(uuid.getnode()))

    raw = "|".join(componentes).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest().upper()
    return f"SAP-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"


def generar_clave_licencia(
    hardware_id: str,
    tipo_licencia: str,
    cliente: str = "Comercio",
    dias_validez: Optional[int] = None,
) -> str:
    """
    Genera una clave de activación firmada criptográficamente (HMAC-SHA256)
    vinculada al Hardware ID del cliente.
    Tipos válidos: 'BASE', 'FULL_PRO', 'DEMO_7_DIAS'
    """
    hw_clean = hardware_id.strip().upper()
    tipo_clean = tipo_licencia.strip().upper()
    if tipo_clean not in ("BASE", "FULL_PRO", "DEMO_7_DIAS"):
        raise ValueError("Tipo de licencia inválido. Use BASE, FULL_PRO o DEMO_7_DIAS.")

    if tipo_clean == "DEMO_7_DIAS" and dias_validez is None:
        dias_validez = 7

    fecha_emision = datetime.now().strftime("%Y-%m-%d")
    if dias_validez:
        fecha_venc = (datetime.now() + timedelta(days=dias_validez)).strftime("%Y-%m-%d")
    else:
        fecha_venc = "PERMANENTE"

    payload = {
        "hw": hw_clean,
        "t": tipo_clean,
        "c": cliente.strip()[:40],
        "e": fecha_emision,
        "v": fecha_venc,
    }
    payload_bytes = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")
    payload_b64 = base64.urlsafe_b64encode(payload_bytes).decode("ascii").rstrip("=")

    firma = hmac.new(_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256).hexdigest()[:16].upper()
    return f"LIC-{tipo_clean}-{payload_b64}.{firma}"


def verificar_clave_licencia(clave: str, hardware_id_actual: Optional[str] = None) -> Dict[str, Any]:
    """
    Verifica si una clave de licencia es auténtica, corresponde a esta PC y no venció.
    Tolera comillas accidentales, espacios en blanco o saltos de línea al copiar y pegar.
    """
    if hardware_id_actual is None:
        hardware_id_actual = obtener_hardware_id()

    hw_actual = re.sub(r"[^A-Za-z0-9_-]", "", str(hardware_id_actual or "")).upper()
    clave_limpia = re.sub(r"[^A-Za-z0-9_.-]", "", str(clave or ""))

    if not clave_limpia or "." not in clave_limpia:
        return {"valida": False, "motivo": "Formato de clave inválido."}

    try:
        prefijo_y_payload, firma_recibida = clave_limpia.rsplit(".", 1)
        partes_prefijo = prefijo_y_payload.split("-", 2)
        if len(partes_prefijo) != 3 or partes_prefijo[0] != "LIC":
            return {"valida": False, "motivo": "Estructura de licencia no reconocida."}

        payload_b64 = partes_prefijo[2]
        firma_esperada = (
            hmac.new(_MASTER_SECRET, payload_b64.encode("ascii"), hashlib.sha256)
            .hexdigest()[:16]
            .upper()
        )

        if not hmac.compare_digest(firma_recibida.upper(), firma_esperada):
            return {"valida": False, "motivo": "Firma criptográfica inválida (clave adulterada)."}

        # Decodificar payload
        padding = "=" * (-len(payload_b64) % 4)
        payload_json = base64.urlsafe_b64decode((payload_b64 + padding).encode("ascii")).decode("utf-8")
        datos = json.loads(payload_json)

        hw_licencia = datos.get("hw", "").upper()
        # Permitir comodín MASTER-ANY-PC sólo si el dueño lo genera explícitamente
        if hw_licencia != hw_actual and hw_licencia != "SAP-MASTER-ANY":
            return {
                "valida": False,
                "motivo": f"Esta clave pertenece a otra PC ({hw_licencia}). Tu ID actual es {hw_actual}.",
            }

        fecha_venc = datos.get("v", "PERMANENTE")
        dias_restantes = None
        if fecha_venc != "PERMANENTE":
            dt_venc = datetime.strptime(fecha_venc, "%Y-%m-%d").date()
            hoy = datetime.now().date()
            dias_restantes = (dt_venc - hoy).days
            if dias_restantes < 0:
                return {
                    "valida": False,
                    "vencida": True,
                    "motivo": f"La licencia DEMO venció el {fecha_venc}. Contactá a soporte para activar tu licencia definitiva.",
                }

        tipo = datos.get("t", "BASE")
        return {
            "valida": True,
            "tipo": tipo,
            "cliente": datos.get("c", "Comercio"),
            "hardware_id": hw_actual,
            "fecha_emision": datos.get("e"),
            "fecha_vencimiento": fecha_venc,
            "dias_restantes": dias_restantes,
        }
    except Exception as e:
        return {"valida": False, "motivo": f"Error al validar clave: {str(e)}"}


def _cargar_uso() -> Dict[str, Any]:
    if USAGE_FILE.exists():
        try:
            with open(USAGE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"usos_comparador": 0, "usos_radar_ml": 0}


def _guardar_uso(uso: Dict[str, Any]) -> None:
    with open(USAGE_FILE, "w", encoding="utf-8") as f:
        json.dump(uso, f, indent=2, ensure_ascii=False)


def obtener_estado_licencia_actual() -> Dict[str, Any]:
    """
    Lee la licencia guardada en disco y devuelve los permisos de cada pestaña
    y cuántas pruebas gratis le quedan en caso de tener LICENCIA BASE.
    """
    hw_id = obtener_hardware_id()
    uso = _cargar_uso()
    max_pruebas_base = 3

    if not LICENSE_FILE.exists():
        return {
            "activada": False,
            "hardware_id": hw_id,
            "tipo": "SIN_ACTIVAR",
            "cliente": "Comercio no activado",
            "motivo": "El sistema requiere activación obligatoria para comenzar tu prueba gratuita de 7 días.",
            "mensaje": "¡Bienvenido! Solicitá tu clave gratuita de 7 días enviando tu código por WhatsApp.",
            "permisos": {
                "pestana_1_actualizador": False,
                "pestana_2_comparador": False,
                "pestana_3_radar_ml": False,
                "pestana_4_corporativo": False,
            },
            "pruebas_restantes": {
                "comparador": 0,
                "radar_ml": 0,
            },
            "requiere_activacion": True,
        }

    try:
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            guardado = json.load(f)
        clave = guardado.get("clave", "")
    except Exception:
        clave = ""

    verif = verificar_clave_licencia(clave, hw_id)
    if not verif.get("valida"):
        vencida = bool(verif.get("vencida", False))
        return {
            "activada": False,
            "hardware_id": hw_id,
            "tipo": "VENCIDA" if vencida else "INVALIDA",
            "cliente": "Comercio",
            "motivo": verif.get("motivo", "Licencia no válida o vencida"),
            "mensaje": (
                "Tu período de prueba gratuita de 7 días ha finalizado. Para continuar utilizando el sistema sin límites, contactá a soporte por WhatsApp para activar tu Licencia Definitiva FULL PRO."
                if vencida
                else verif.get("motivo", "Licencia no válida")
            ),
            "permisos": {
                "pestana_1_actualizador": False,
                "pestana_2_comparador": False,
                "pestana_3_radar_ml": False,
                "pestana_4_corporativo": False,
            },
            "pruebas_restantes": {
                "comparador": 0,
                "radar_ml": 0,
            },
            "requiere_upgrade": True,
            "vencida": vencida,
        }

    tipo = verif["tipo"]
    restantes_comp = max(0, max_pruebas_base - int(uso.get("usos_comparador", 0)))
    restantes_ml = max(0, max_pruebas_base - int(uso.get("usos_radar_ml", 0)))

    if tipo in ("FULL_PRO", "DEMO_7_DIAS"):
        permisos = {
            "pestana_1_actualizador": True,
            "pestana_2_comparador": True,
            "pestana_3_radar_ml": True,
            "pestana_4_corporativo": True,
        }
    else:  # BASE
        permisos = {
            "pestana_1_actualizador": True,
            "pestana_2_comparador": restantes_comp > 0,
            "pestana_3_radar_ml": restantes_ml > 0,
            "pestana_4_corporativo": True,
        }

    return {
        "activada": True,
        "hardware_id": hw_id,
        "tipo": tipo,
        "cliente": verif.get("cliente", "Comercio"),
        "fecha_emision": verif.get("fecha_emision"),
        "fecha_vencimiento": verif.get("fecha_vencimiento"),
        "dias_restantes": verif.get("dias_restantes"),
        "clave": clave,
        "permisos": permisos,
        "pruebas_restantes": {
            "comparador": "ILIMITADO" if tipo in ("FULL_PRO", "DEMO_7_DIAS") else restantes_comp,
            "radar_ml": "ILIMITADO" if tipo in ("FULL_PRO", "DEMO_7_DIAS") else restantes_ml,
        },
    }


def activar_licencia_en_disco(clave: str) -> Dict[str, Any]:
    """Valida y guarda una clave de licencia en la PC del comerciante."""
    clave_limpia = re.sub(r"[^A-Za-z0-9_.-]", "", str(clave or ""))
    verif = verificar_clave_licencia(clave_limpia)
    if not verif.get("valida"):
        return verif

    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        json.dump(
            {
                "clave": clave_limpia,
                "activada_el": datetime.now().isoformat(),
            },
            f,
            indent=2,
            ensure_ascii=False,
        )
    return obtener_estado_licencia_actual()


def consumir_prueba_si_es_base(modulo: str) -> Dict[str, Any]:
    """
    Si la licencia activa es BASE, descuenta 1 uso de prueba del módulo ('comparador' o 'radar_ml').
    Si ya agotó las 3 pruebas gratis, devuelve permitido=False con el mensaje comercial para hacer upgrade a FULL PRO.
    """
    estado = obtener_estado_licencia_actual()
    if not estado.get("activada"):
        return {
            "permitido": False,
            "motivo": estado.get("motivo") or "Debés activar tu licencia para usar este módulo.",
        }

    tipo = estado["tipo"]
    if tipo in ("FULL_PRO", "DEMO_7_DIAS"):
        return {"permitido": True, "restantes": "ILIMITADO"}

    uso = _cargar_uso()
    campo = "usos_comparador" if modulo == "comparador" else "usos_radar_ml"
    usados = int(uso.get(campo, 0))
    if usados >= 3:
        return {
            "permitido": False,
            "bloqueo_upgrade": True,
            "motivo": (
                "¡Completaste tus 3 pruebas gratuitas de este módulo en tu LICENCIA BASE! "
                "Solicitá tu actualización a LICENCIA FULL PRO para destrabar el Comparador de Proveedores "
                "y el Radar MercadoLibre sin límites para siempre."
            ),
        }

    uso[campo] = usados + 1
    _guardar_uso(uso)
    return {"permitido": True, "restantes": max(0, 3 - uso[campo])}
