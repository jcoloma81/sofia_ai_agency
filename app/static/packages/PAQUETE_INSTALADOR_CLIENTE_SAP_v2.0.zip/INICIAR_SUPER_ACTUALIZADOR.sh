#!/usr/bin/env bash
cd "$(dirname "$0")"
PORT=8765
echo "================================================================="
echo "🚀 Iniciando Súper Actualizador Pro (Edición Enterprise Local)..."
echo "🌐 Abriendo en tu navegador: http://127.0.0.1:$PORT"
echo "================================================================="
(sleep 1.5 && xdg-open "http://127.0.0.1:$PORT" >/dev/null 2>&1 || true) &
./venv/bin/uvicorn app:app --host 127.0.0.1 --port $PORT
